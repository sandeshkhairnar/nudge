"use client";

import { JSX, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { usePathname } from "next/navigation";

/* ── LOGO ── */
function NudgeLogo({ collapsed }: { collapsed: boolean }) {
  const id = "sidebar-pills";
  return (
    <div style={{ overflow: "hidden", height: 36 }}>
      <AnimatePresence mode="wait">
        {collapsed ? (
          <motion.svg key="icon" initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.8 }}
            width="36" height="36" viewBox="0 0 48 48" fill="none">
            <g id={id + "-c"}>
              <rect x="6" y="6" width="16" height="16" rx="8" fill="#36C5F0" />
              <rect x="6" y="26" width="16" height="16" rx="4" fill="#36C5F0" opacity="0.4" />
              <rect x="26" y="6" width="16" height="16" rx="4" fill="#2EB67D" opacity="0.4" />
              <rect x="26" y="26" width="16" height="16" rx="8" fill="#2EB67D" />
              <animateTransform href={`#${id}-c`} attributeName="transform" type="rotate"
                values="0 24 24;-30 24 24;-60 24 24;-90 24 24;-120 24 24;-150 24 24;-180 24 24;-210 24 24;-240 24 24;-270 24 24;-300 24 24;-330 24 24;-360 24 24"
                keyTimes="0;0.05;0.1;0.15;0.25;0.35;0.45;0.55;0.65;0.75;0.85;0.95;1"
                dur="6s" repeatCount="indefinite" />
            </g>
          </motion.svg>
        ) : (
          <motion.svg key="full" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            width="130" height="36" viewBox="0 0 220 56" fill="none">
            <g id={id + "-f"}>
              <rect x="8" y="8" width="16" height="16" rx="8" fill="#36C5F0" />
              <rect x="8" y="26" width="16" height="16" rx="4" fill="#36C5F0" opacity="0.4" />
              <rect x="26" y="8" width="16" height="16" rx="4" fill="#2EB67D" opacity="0.4" />
              <rect x="26" y="26" width="16" height="16" rx="8" fill="#2EB67D" />
              <animateTransform href={`#${id}-f`} attributeName="transform" type="rotate"
                values="0 24 24;-30 24 24;-60 24 24;-90 24 24;-120 24 24;-150 24 24;-180 24 24;-210 24 24;-240 24 24;-270 24 24;-300 24 24;-330 24 24;-360 24 24"
                keyTimes="0;0.05;0.1;0.15;0.25;0.35;0.45;0.55;0.65;0.75;0.85;0.95;1"
                dur="6s" repeatCount="indefinite" />
            </g>
            <text x="56" y="37" fontFamily="'Sora',sans-serif" fontWeight="800" fontSize="28" fill="#fff" letterSpacing="-1">nudge</text>
          </motion.svg>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ── ICONS ── */
const icons: Record<string, JSX.Element> = {
  home: <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M3 12L12 3l9 9M5 10v9a1 1 0 001 1h4v-5h4v5h4a1 1 0 001-1v-9" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  board: <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="7" height="9" rx="2" stroke="currentColor" strokeWidth="1.8"/><rect x="14" y="3" width="7" height="5" rx="2" stroke="currentColor" strokeWidth="1.8"/><rect x="14" y="12" width="7" height="9" rx="2" stroke="currentColor" strokeWidth="1.8"/><rect x="3" y="16" width="7" height="5" rx="2" stroke="currentColor" strokeWidth="1.8"/></svg>,
  inbox: <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M3 8l7.9 5.3a2 2 0 002.2 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>,
  team: <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="9" cy="7" r="3" stroke="currentColor" strokeWidth="1.8"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/><circle cx="17" cy="7" r="2.5" stroke="currentColor" strokeWidth="1.7"/><path d="M21 20c0-2.8-1.8-5-4-5.5" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"/></svg>,
  analytics: <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M3 20h18M7 20V12M12 20V8M17 20V4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>,
  nudges: <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M13 2L4.5 13.5H12L11 22L19.5 10.5H12L13 2z" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  settings: <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.8"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z" stroke="currentColor" strokeWidth="1.8"/></svg>,
};

/* ── NAV ITEMS ── */
const navItems = [
  { label: "Dashboard",  href: "/space",  icon: "home" },
  { label: "Boards",     href: "/boards",     icon: "board" },
  { label: "Inbox",      href: "/inbox",      icon: "inbox",    badge: 4 },
  { label: "My Nudges",  href: "/nudges",     icon: "nudges",   badge: 2 },
  { label: "Team",       href: "/team",       icon: "team" },
  { label: "Analytics",  href: "/analytics",  icon: "analytics" },
];

const bottomItems = [
  { label: "Settings", href: "/settings", icon: "settings" },
];

/* ── PROJECT LIST ── */
const projects = [
  { name: "Q3 Launch", color: "#36C5F0", progress: 72 },
  { name: "Auth Refactor", color: "#2EB67D", progress: 45 },
  { name: "Design System", color: "#ECB22E", progress: 88 },
  { name: "API v2", color: "#E01E5A", progress: 20 },
];

/* ── NAV ITEM COMPONENT ── */
function NavItem({ item, collapsed, active }: { item: typeof navItems[0]; collapsed: boolean; active: boolean }) {
  return (
    <Link href={item.href} style={{ textDecoration: "none" }}>
      <motion.div
        whileHover={{ x: collapsed ? 0 : 2 }}
        style={{
          display: "flex", alignItems: "center",
          gap: 10, padding: collapsed ? "10px" : "10px 12px",
          borderRadius: 10, cursor: "pointer",
          justifyContent: collapsed ? "center" : "flex-start",
          background: active ? "rgba(255,255,255,0.1)" : "transparent",
          position: "relative",
          transition: "background 0.2s",
        }}
      >
        {active && (
          <motion.div layoutId="nav-active"
            style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: 3, background: "#36C5F0", borderRadius: "0 2px 2px 0" }} />
        )}
        <span style={{ color: active ? "#fff" : "rgba(255,255,255,0.42)", flexShrink: 0, transition: "color 0.2s" }}>
          {icons[item.icon]}
        </span>
        <AnimatePresence>
          {!collapsed && (
            <motion.span initial={{ opacity: 0, width: 0 }} animate={{ opacity: 1, width: "auto" }} exit={{ opacity: 0, width: 0 }}
              style={{ fontSize: 13, fontWeight: active ? 700 : 600, color: active ? "#fff" : "rgba(255,255,255,0.48)", whiteSpace: "nowrap", overflow: "hidden", transition: "color 0.2s" }}>
              {item.label}
            </motion.span>
          )}
        </AnimatePresence>
        {!collapsed && (item as any).badge && (
          <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }}
            style={{ marginLeft: "auto", minWidth: 18, height: 18, borderRadius: 100, background: "#36C5F0", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 800, color: "#fff", padding: "0 5px" }}>
            {(item as any).badge}
          </motion.span>
        )}
      </motion.div>
    </Link>
  );
}

/* ── SIDEBAR ── */
export default function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const pathname = usePathname();

  const W = collapsed ? 68 : 240;

  return (
    <motion.aside
      animate={{ width: W }}
      transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
      style={{
        height: "100vh", background: "#0D0D0D",
        display: "flex", flexDirection: "column",
        borderRight: "1px solid rgba(255,255,255,0.06)",
        overflow: "hidden", flexShrink: 0, position: "relative",
      }}
    >
      {/* Subtle dot grid */}
      <div style={{ position: "absolute", inset: 0, backgroundImage: "radial-gradient(rgba(255,255,255,0.04) 1px,transparent 1px)", backgroundSize: "24px 24px", pointerEvents: "none" }} />

      {/* Top accent blob */}
      <div style={{ position: "absolute", top: -60, right: -40, width: 200, height: 200, borderRadius: "50%", background: "radial-gradient(ellipse,rgba(54,197,240,0.08) 0%,transparent 70%)", filter: "blur(30px)", pointerEvents: "none" }} />

      {/* ── HEADER ── */}
      <div style={{ padding: collapsed ? "20px 16px" : "20px 20px", display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: "1px solid rgba(255,255,255,0.05)", position: "relative", flexShrink: 0 }}>
        <NudgeLogo collapsed={collapsed} />
        <motion.button
          whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}
          onClick={() => setCollapsed(c => !c)}
          style={{ width: 28, height: 28, borderRadius: 8, background: "rgba(255,255,255,0.06)", border: "none", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, color: "rgba(255,255,255,0.4)" }}
        >
          <motion.svg animate={{ rotate: collapsed ? 180 : 0 }} transition={{ duration: 0.3 }}
            width="14" height="14" viewBox="0 0 24 24" fill="none">
            <path d="M15 18l-6-6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </motion.svg>
        </motion.button>
      </div>

      {/* ── WORKSPACE BADGE ── */}
      {!collapsed && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          style={{ padding: "14px 20px", borderBottom: "1px solid rgba(255,255,255,0.05)", flexShrink: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 10px", background: "rgba(255,255,255,0.05)", borderRadius: 10, cursor: "pointer" }}>
            <div style={{ width: 28, height: 28, borderRadius: 8, background: "linear-gradient(135deg,#36C5F0,#2EB67D)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 800, color: "#fff", flexShrink: 0 }}>A</div>
            <div style={{ flex: 1, overflow: "hidden" }}>
              <p style={{ fontSize: 13, fontWeight: 700, color: "#fff", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>Acme Inc.</p>
              <p style={{ fontSize: 11, color: "rgba(255,255,255,0.3)", marginTop: 1 }}>Team plan</p>
            </div>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M6 9l6 6 6-6" stroke="rgba(255,255,255,0.3)" strokeWidth="1.8" strokeLinecap="round"/></svg>
          </div>
        </motion.div>
      )}

      {/* ── MAIN NAV ── */}
      <nav style={{ flex: 1, padding: collapsed ? "12px 10px" : "12px 12px", display: "flex", flexDirection: "column", gap: 2, overflowY: "auto", overflowX: "hidden", position: "relative" }}>
        {navItems.map(item => (
          <NavItem key={item.href} item={item} collapsed={collapsed} active={pathname === item.href || pathname.startsWith(item.href + "/")} />
        ))}

        {/* Projects section */}
        {!collapsed && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} style={{ marginTop: 24 }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 12px", marginBottom: 8 }}>
              <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: "0.14em", textTransform: "uppercase", color: "rgba(255,255,255,0.22)" }}>Projects</span>
              <motion.button whileHover={{ scale: 1.1 }} style={{ background: "none", border: "none", cursor: "pointer", color: "rgba(255,255,255,0.3)", padding: 2 }}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>
              </motion.button>
            </div>
           {projects.map((p, i) => (
  <Link
    key={p.name}
    href={`/space/${encodeURIComponent(p.name)}`}
    style={{ textDecoration: "none" }}
  >
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: i * 0.06 }}
      whileHover={{ x: 2, background: "rgba(255,255,255,0.04)" }}
      style={{
        display: "flex",
        alignItems: "center",
        gap: 10,
        padding: "8px 12px",
        borderRadius: 8,
        cursor: "pointer",
        transition: "background 0.2s",
      }}
    >
      <div
        style={{
          width: 8,
          height: 8,
          borderRadius: "50%",
          background: p.color,
          flexShrink: 0,
        }}
      />

      <span
        style={{
          fontSize: 13,
          fontWeight: 600,
          color: "rgba(255,255,255,0.5)",
          flex: 1,
          whiteSpace: "nowrap",
          overflow: "hidden",
          textOverflow: "ellipsis",
        }}
      >
        {p.name}
      </span>

      <div
        style={{
          width: 36,
          height: 3,
          borderRadius: 2,
          background: "rgba(255,255,255,0.08)",
          overflow: "hidden",
          flexShrink: 0,
        }}
      >
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${p.progress}%` }}
          transition={{
            delay: 0.3 + i * 0.06,
            duration: 0.8,
            ease: [0.16, 1, 0.3, 1],
          }}
          style={{
            height: "100%",
            background: p.color,
            borderRadius: 2,
          }}
        />
      </div>
    </motion.div>
  </Link>
))}
          </motion.div>
        )}
      </nav>

      {/* ── BOTTOM ── */}
      <div style={{ padding: collapsed ? "12px 10px" : "12px 12px", borderTop: "1px solid rgba(255,255,255,0.05)", flexShrink: 0, position: "relative" }}>
        {bottomItems.map(item => (
          <NavItem key={item.href} item={item} collapsed={collapsed} active={pathname === item.href} />
        ))}

        {/* Avatar */}
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: collapsed ? "10px 0" : "10px 12px", marginTop: 4, cursor: "pointer", justifyContent: collapsed ? "center" : "flex-start" }}>
          <div style={{ width: 32, height: 32, borderRadius: "50%", background: "linear-gradient(135deg,#36C5F0,#2EB67D)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 800, color: "#fff", flexShrink: 0 }}>S</div>
          {!collapsed && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} style={{ overflow: "hidden" }}>
              <p style={{ fontSize: 13, fontWeight: 700, color: "rgba(255,255,255,0.8)", whiteSpace: "nowrap" }}>Sandesh</p>
              <p style={{ fontSize: 11, color: "rgba(255,255,255,0.28)" }}>sandesh@acme.io</p>
            </motion.div>
          )}
        </div>
      </div>
    </motion.aside>
  );
}