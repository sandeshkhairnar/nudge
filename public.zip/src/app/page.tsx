"use client";

import { useState, useEffect, useRef } from "react";
import {
  motion,
  useScroll,
  useTransform,
  useSpring,
  useInView,
  AnimatePresence,
  useMotionValue,
  useAnimationFrame,
  useMotionTemplate,
} from "framer-motion";
import Link from "next/link";

/* ═══════════════════════════════════════════════════════════
   LOGO
═══════════════════════════════════════════════════════════ */
function NudgeLogo({ scale = 1, dark = false }: { scale?: number; dark?: boolean }) {
  const id = `pills-${scale}-${dark ? "d" : "l"}-${Math.random().toString(36).slice(2, 6)}`;
  return (
    <svg width={220 * scale} height={56 * scale} viewBox="0 0 220 56" fill="none">
      <g id={id}>
        <rect x="8" y="8" width="16" height="16" rx="8" fill="#36C5F0" />
        <rect x="8" y="26" width="16" height="16" rx="4" fill="#36C5F0" opacity="0.4" />
        <rect x="26" y="8" width="16" height="16" rx="4" fill="#2EB67D" opacity="0.4" />
        <rect x="26" y="26" width="16" height="16" rx="8" fill="#2EB67D" />
        <animateTransform href={`#${id}`} attributeName="transform" type="rotate"
          values="0 24 24;-30 24 24;-60 24 24;-90 24 24;-120 24 24;-150 24 24;-180 24 24;-210 24 24;-240 24 24;-270 24 24;-300 24 24;-330 24 24;-360 24 24"
          keyTimes="0;0.05;0.1;0.15;0.25;0.35;0.45;0.55;0.65;0.75;0.85;0.95;1"
          dur="6s" repeatCount="indefinite" />
      </g>
      <text x="56" y="37" fontFamily="'Sora',sans-serif" fontWeight="800" fontSize="28"
        fill={dark ? "#fff" : "#0D0D0D"} letterSpacing="-1">nudge</text>
    </svg>
  );
}

/* ═══════════════════════════════════════════════════════════
   MAGNETIC BUTTON
═══════════════════════════════════════════════════════════ */
function MagBtn({ children, style = {}, onClick }: any) {
  const ref = useRef<HTMLButtonElement>(null);
  const x = useMotionValue(0); const y = useMotionValue(0);
  const sx = useSpring(x, { stiffness: 200, damping: 20 });
  const sy = useSpring(y, { stiffness: 200, damping: 20 });
  return (
    <motion.button ref={ref} style={{ x: sx, y: sy, ...style }}
      onMouseMove={e => { const r = ref.current!.getBoundingClientRect(); x.set((e.clientX - r.left - r.width / 2) * 0.35); y.set((e.clientY - r.top - r.height / 2) * 0.35); }}
      onMouseLeave={() => { x.set(0); y.set(0); }}
      whileTap={{ scale: 0.96 }} onClick={onClick}>
      {children}
    </motion.button>
  );
}

/* ═══════════════════════════════════════════════════════════
   SCROLL PROGRESS BAR
═══════════════════════════════════════════════════════════ */
function ScrollBar() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 100, damping: 30 });
  return (
    <motion.div style={{
      position: "fixed", top: 0, left: 0, right: 0, height: 3, zIndex: 9999,
      background: "linear-gradient(90deg,#36C5F0,#2EB67D,#ECB22E)",
      scaleX, transformOrigin: "left",
    }} />
  );
}

/* ═══════════════════════════════════════════════════════════
   CUSTOM CURSOR
═══════════════════════════════════════════════════════════ */
function Cursor() {
  const mx = useMotionValue(-100); const my = useMotionValue(-100);
  const gx = useSpring(mx, { stiffness: 80, damping: 18 });
  const gy = useSpring(my, { stiffness: 80, damping: 18 });
  useEffect(() => {
    const fn = (e: MouseEvent) => { mx.set(e.clientX); my.set(e.clientY); };
    window.addEventListener("mousemove", fn);
    return () => window.removeEventListener("mousemove", fn);
  }, []);
  return (
    <>
      <motion.div style={{ position: "fixed", top: 0, left: 0, width: 8, height: 8, borderRadius: "50%", background: "#0D0D0D", pointerEvents: "none", zIndex: 9998, x: mx, y: my, translateX: "-50%", translateY: "-50%" }} />
      <motion.div style={{ position: "fixed", top: 0, left: 0, width: 440, height: 440, borderRadius: "50%", pointerEvents: "none", zIndex: 9997, x: gx, y: gy, translateX: "-50%", translateY: "-50%", background: "radial-gradient(circle, rgba(54,197,240,0.07) 0%, transparent 70%)" }} />
    </>
  );
}

/* ═══════════════════════════════════════════════════════════
   TICKER
═══════════════════════════════════════════════════════════ */
const TICKS = ["Move tasks forward", "Ship without chaos", "Real-time clarity", "No stuck tickets", "AI that nudges", "Built for teams"];
function Ticker({ reverse = false }: { reverse?: boolean }) {
  const x = useMotionValue(0);
  const ref = useRef<HTMLDivElement>(null);
  const w = useRef(0);
  useEffect(() => { if (ref.current) w.current = ref.current.scrollWidth / 2; }, []);
  useAnimationFrame((_, dt) => {
    const v = reverse ? dt * 0.05 : -dt * 0.05;
    const next = x.get() + v;
    if (!reverse && Math.abs(next) >= w.current) x.set(0);
    else if (reverse && next >= 0) x.set(-w.current);
    else x.set(next);
  });
  const items = [...TICKS, ...TICKS, ...TICKS, ...TICKS];
  return (
    <div style={{ overflow: "hidden", padding: "12px 0" }}>
      <motion.div ref={ref} style={{ x, display: "flex", whiteSpace: "nowrap" }}>
        {items.map((t, i) => (
          <span key={i} style={{ display: "inline-flex", alignItems: "center", gap: 18, padding: "0 24px", fontSize: 11, fontWeight: 700, letterSpacing: "0.16em", textTransform: "uppercase", color: reverse ? "rgba(255,255,255,0.18)" : "#9CA3AF" }}>
            {t} <span style={{ color: reverse ? "#2EB67D" : "#36C5F0", fontSize: 9 }}>✦</span>
          </span>
        ))}
      </motion.div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   REVEAL
═══════════════════════════════════════════════════════════ */
function Reveal({ children, delay = 0, x = 0, y = 40 }: any) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-8% 0px" });
  return (
    <motion.div ref={ref} initial={{ opacity: 0, y, x }} animate={inView ? { opacity: 1, y: 0, x: 0 } : {}}
      transition={{ duration: 0.8, delay, ease: [0.16, 1, 0.3, 1] }}>
      {children}
    </motion.div>
  );
}

/* ═══════════════════════════════════════════════════════════
   COUNT-UP NUMBER
═══════════════════════════════════════════════════════════ */
function CountUp({ to, suffix = "", duration = 1.8 }: { to: number; suffix?: string; duration?: number }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true });
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!inView) return;
    const start = performance.now();
    const tick = (now: number) => {
      const p = Math.min((now - start) / (duration * 1000), 1);
      const ease = 1 - Math.pow(1 - p, 4);
      setVal(Math.floor(ease * to));
      if (p < 1) requestAnimationFrame(tick);
      else setVal(to);
    };
    requestAnimationFrame(tick);
  }, [inView, to, duration]);
  return <span ref={ref}>{val.toLocaleString()}{suffix}</span>;
}

/* ═══════════════════════════════════════════════════════════
   HORIZONTAL SCROLL CARDS SECTION
═══════════════════════════════════════════════════════════ */
const hCards = [
  { accent: "#36C5F0", icon: "⚡", title: "Zero-config setup", body: "Connect your team in 3 minutes. No CSV uploads, no onboarding calls, no IT tickets." },
  { accent: "#2EB67D", icon: "🧠", title: "AI that listens", body: "Nudge reads the room — task history, comments, team patterns — before it ever sends a reminder." },
  { accent: "#ECB22E", icon: "🎯", title: "One signal, not noise", body: "One nudge per stalled task. Not a digest. Not a badge. The exact message to the exact person." },
  { accent: "#E01E5A", icon: "📊", title: "Live pulse board", body: "Your team's velocity as a heartbeat. Instantly see what's moving and what's flatlining." },
  { accent: "#A259FF", icon: "🔗", title: "Every tool, one thread", body: "GitHub, Figma, Slack, Linear — every artefact linked on the task, not buried in a thread." },
];

function HorizontalCards() {
  const trackRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: trackRef, offset: ["start start", "end end"] });
  const x = useTransform(scrollYProgress, [0, 1], ["0%", "-72%"]);
  const smoothX = useSpring(x, { stiffness: 60, damping: 20 });

  return (
    <div ref={trackRef} style={{ height: `${hCards.length * 80}vh`, position: "relative" }}>
      <div style={{ position: "sticky", top: 0, height: "100vh", overflow: "hidden", display: "flex", alignItems: "center" }}>
        {/* Section label */}
        <div style={{ position: "absolute", top: 48, left: 48, display: "flex", alignItems: "center", gap: 14 }}>
          <span style={{ width: 32, height: 2, background: "#0D0D0D", display: "block" }} />
          <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.18em", textTransform: "uppercase", color: "#0D0D0D" }}>Why teams switch</span>
        </div>

        {/* Scroll hint */}
        <div style={{ position: "absolute", bottom: 40, left: 48, display: "flex", alignItems: "center", gap: 10 }}>
          <motion.div animate={{ x: [0, 10, 0] }} transition={{ duration: 1.4, repeat: Infinity }} style={{ fontSize: 13, color: "#9CA3AF" }}>
            scroll to explore →
          </motion.div>
        </div>

        <motion.div style={{ x: smoothX, display: "flex", gap: 24, paddingLeft: 48, paddingRight: 200, alignItems: "center" }}>
          {/* Big heading card */}
          <div style={{ flexShrink: 0, width: 480 }}>
            <h2 style={{ fontSize: "clamp(48px,6vw,76px)", fontWeight: 800, lineHeight: 1.02, letterSpacing: "-0.035em", color: "#0D0D0D" }}>
              Everything<br />you need.<br />
              <span style={{ color: "#36C5F0" }}>Nothing</span><br />you don't.
            </h2>
          </div>

          {/* Feature cards */}
          {hCards.map((c, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
              whileHover={{ y: -8, boxShadow: `0 24px 64px ${c.accent}22` }}
              style={{
                flexShrink: 0, width: 340, height: 420,
                background: "#fff", borderRadius: 24,
                border: "1px solid #EBEBEB",
                padding: "48px 40px",
                display: "flex", flexDirection: "column", justifyContent: "space-between",
                boxShadow: "0 4px 24px rgba(0,0,0,0.05)",
                transition: "box-shadow 0.3s",
                cursor: "default",
              }}
            >
              <div>
                <div style={{ width: 52, height: 52, borderRadius: 14, background: `${c.accent}18`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, marginBottom: 28 }}>
                  {c.icon}
                </div>
                <h3 style={{ fontSize: 22, fontWeight: 800, letterSpacing: "-0.02em", color: "#0D0D0D", marginBottom: 14, lineHeight: 1.15 }}>{c.title}</h3>
                <p style={{ fontSize: 15, color: "#6B7280", lineHeight: 1.72, fontWeight: 400 }}>{c.body}</p>
              </div>
              <div style={{ width: 32, height: 3, background: c.accent, borderRadius: 2 }} />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   STICKY FEATURE SECTION  (text swaps as you scroll)
═══════════════════════════════════════════════════════════ */
const stickyFeatures = [
  { accent: "#36C5F0", tag: "01 · Organisation", title: "Boards that\nbreathe with you", body: "Your board reorganises around urgency, blockers, and what's gone quiet. No manual grooming. It just works." },
  { accent: "#2EB67D", tag: "02 · Intelligence", title: "The nudge\nengine", body: "One precise prompt when a task stalls. The AI watches context, not just time. No noise. No badge anxiety." },
  { accent: "#ECB22E", tag: "03 · Insight", title: "Velocity, not\nvanity metrics", body: "Three numbers: shipped, stuck, at risk. That's the whole picture. Burn-down charts gather dust." },
  { accent: "#E01E5A", tag: "04 · Integration", title: "Context\ntravels", body: "PRs, designs, messages — every artefact lives on the task. No more digging through Slack threads." },
];

function StickyFeatures() {
  const trackRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: trackRef, offset: ["start start", "end end"] });
  const activeRaw = useTransform(scrollYProgress, [0, 1], [0, stickyFeatures.length - 0.001]);
  const [active, setActive] = useState(0);
  useEffect(() => activeRaw.on("change", v => setActive(Math.floor(v))), []);

  const f = stickyFeatures[active];

  // Progress line within current feature
  const segSize = 1 / stickyFeatures.length;
  const segStart = active * segSize;
  const segProgress = useTransform(scrollYProgress, [segStart, segStart + segSize], [0, 1]);
  const lineScaleY = useSpring(segProgress, { stiffness: 60, damping: 18 });

  return (
    <div ref={trackRef} style={{ height: `${stickyFeatures.length * 100}vh`, position: "relative" }}>
      <div style={{ position: "sticky", top: 0, height: "100vh", display: "flex", alignItems: "center", overflow: "hidden" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 48px", width: "100%", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 80, alignItems: "center" }}>

          {/* Left: text content */}
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 32 }}>
              <span style={{ width: 32, height: 2, background: "#0D0D0D", display: "block" }} />
              <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.18em", textTransform: "uppercase" }}>How it works</span>
            </div>

            {/* Feature index nav */}
            <div style={{ display: "flex", gap: 8, marginBottom: 56 }}>
              {stickyFeatures.map((_, i) => (
                <motion.div key={i}
                  animate={{ background: i === active ? f.accent : "#E8E8E2", width: i === active ? 32 : 12 }}
                  transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                  style={{ height: 4, borderRadius: 2 }}
                />
              ))}
            </div>

            <AnimatePresence mode="wait">
              <motion.div key={active}
                initial={{ opacity: 0, y: 30, filter: "blur(6px)" }}
                animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                exit={{ opacity: 0, y: -20, filter: "blur(4px)" }}
                transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
              >
                <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.14em", textTransform: "uppercase", color: f.accent, display: "block", marginBottom: 16 }}>
                  {f.tag}
                </span>
                <h2 style={{ fontSize: "clamp(36px,4.5vw,60px)", fontWeight: 800, letterSpacing: "-0.03em", lineHeight: 1.05, color: "#0D0D0D", marginBottom: 24, whiteSpace: "pre-line" }}>
                  {f.title}
                </h2>
                <p style={{ fontSize: 17, color: "#6B7280", lineHeight: 1.72, maxWidth: 420 }}>
                  {f.body}
                </p>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Right: animated visual */}
          <AnimatePresence mode="wait">
            <motion.div key={active}
              initial={{ opacity: 0, scale: 0.92, y: 24 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 1.04, y: -16 }}
              transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
              style={{ height: 380, borderRadius: 24, background: "#fff", border: "1px solid #EBEBEB", boxShadow: `0 24px 80px ${f.accent}18`, overflow: "hidden", position: "relative", display: "flex", alignItems: "center", justifyContent: "center" }}
            >
              {/* Accent colour wash */}
              <div style={{ position: "absolute", inset: 0, background: `radial-gradient(ellipse at 30% 30%, ${f.accent}18 0%, transparent 70%)` }} />

              {/* Visual per feature */}
              <FeatureVisual index={active} accent={f.accent} />

              {/* Progress line at bottom */}
              <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: 3, background: "#F0F0EB" }}>
                <motion.div style={{ height: "100%", background: f.accent, scaleX: lineScaleY, transformOrigin: "left" }} />
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

/* Mini visuals for sticky section */
function FeatureVisual({ index, accent }: { index: number; accent: string }) {
  if (index === 0) return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10, width: 260 }}>
      {[
        { label: "Design tokens audit", w: 180, done: true },
        { label: "API rate limiting", w: 220, done: false },
        { label: "Onboarding flow v2", w: 150, done: false },
        { label: "Auth refactor", w: 200, done: true },
      ].map((item, i) => (
        <motion.div key={i} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.08 }}
          style={{ background: item.done ? "#F0F9F4" : "#fff", border: `1px solid ${item.done ? "#C7EDD9" : "#EBEBEB"}`, borderRadius: 10, padding: "12px 16px", display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 16, height: 16, borderRadius: "50%", background: item.done ? "#2EB67D" : "#E8E8E2", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
            {item.done && <svg width="8" height="8" viewBox="0 0 8 8" fill="none"><path d="M1.5 4l2 2 3-3" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>}
          </div>
          <span style={{ fontSize: 13, fontWeight: 600, color: item.done ? "#059669" : "#374151" }}>{item.label}</span>
        </motion.div>
      ))}
    </div>
  );

  if (index === 1) return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10, width: 280 }}>
      <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", stiffness: 200 }}
        style={{ background: "#fff", border: `2px solid ${accent}`, borderRadius: 16, padding: "16px 20px", boxShadow: `0 8px 24px ${accent}22` }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: accent, textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 6 }}>Nudge AI</div>
        <p style={{ fontSize: 14, color: "#374151", lineHeight: 1.55 }}>Hey @marcus — "API rate limiting" has been in progress for 6 days. Any blockers I can flag? 👋</p>
        <div style={{ marginTop: 12, fontSize: 11, color: "#9CA3AF" }}>just now · 1 nudge sent</div>
      </motion.div>
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
        style={{ alignSelf: "flex-end", background: "#F9F9F7", borderRadius: 12, padding: "10px 16px", fontSize: 13, color: "#6B7280" }}>
        on it — deploying a fix now ✅
      </motion.div>
    </div>
  );

  if (index === 2) return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12, width: 280 }}>
      {[
        { label: "Shipped", val: 24, color: "#2EB67D", w: "75%" },
        { label: "Stuck", val: 3, color: "#E01E5A", w: "12%" },
        { label: "At risk", val: 6, color: "#ECB22E", w: "25%" },
      ].map((s, i) => (
        <div key={i}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
            <span style={{ fontSize: 13, fontWeight: 600, color: "#374151" }}>{s.label}</span>
            <span style={{ fontSize: 13, fontWeight: 800, color: s.color }}>{s.val}</span>
          </div>
          <div style={{ height: 8, background: "#F0F0EB", borderRadius: 4, overflow: "hidden" }}>
            <motion.div initial={{ width: 0 }} animate={{ width: s.w }} transition={{ delay: i * 0.15, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              style={{ height: "100%", background: s.color, borderRadius: 4 }} />
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8, width: 280 }}>
      {[
        { icon: "🔀", label: "PR #482 merged", time: "2m ago", color: "#2EB67D" },
        { icon: "🎨", label: "Figma frame linked", time: "18m ago", color: "#A259FF" },
        { icon: "💬", label: "Slack thread attached", time: "1h ago", color: "#36C5F0" },
      ].map((item, i) => (
        <motion.div key={i} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.1 }}
          style={{ background: "#fff", border: "1px solid #EBEBEB", borderRadius: 12, padding: "12px 16px", display: "flex", alignItems: "center", gap: 12 }}>
          <span style={{ fontSize: 18 }}>{item.icon}</span>
          <div style={{ flex: 1 }}>
            <p style={{ fontSize: 13, fontWeight: 600, color: "#374151" }}>{item.label}</p>
            <p style={{ fontSize: 11, color: "#9CA3AF" }}>{item.time}</p>
          </div>
          <div style={{ width: 8, height: 8, borderRadius: "50%", background: item.color }} />
        </motion.div>
      ))}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   SCROLLING TEXT REVEAL  (big masked text)
═══════════════════════════════════════════════════════════ */
function RevealWord({ word, index, total, scrollYProgress }: {
  word: string; index: number; total: number; scrollYProgress: any;
}) {
  const start = Math.min(index / total, 0.99);
  const end = Math.min((index + 1.5) / total, 1.0);
  const opacity = useTransform(scrollYProgress, [start, end], [0.12, 1]);
  const y = useTransform(scrollYProgress, [start, end], [20, 0]);
  return (
    <motion.span style={{
      opacity, y, display: "inline-block",
      color: word === "nudge" ? "#36C5F0" : word === "more." ? "#2EB67D" : "#0D0D0D",
    }}>
      {word}
    </motion.span>
  );
}

function ScrollTextReveal() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const words = ["Your", "team", "is", "one", "nudge", "away", "from", "shipping", "more."];

  return (
    <div ref={ref} style={{ padding: "120px 48px", maxWidth: 1200, margin: "0 auto" }}>
      <h2 style={{ fontSize: "clamp(40px,6vw,80px)", fontWeight: 800, letterSpacing: "-0.035em", lineHeight: 1.08, display: "flex", flexWrap: "wrap", gap: "0 0.2em" }}>
        {words.map((word, i) => (
          <RevealWord key={i} word={word} index={i} total={words.length} scrollYProgress={scrollYProgress} />
        ))}
      </h2>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   DATA
═══════════════════════════════════════════════════════════ */
const testimonials = [
  { quote: "Our retrospectives used to start with 'where did that ticket go?' Now they start with 'look what we shipped.'", name: "Ava Mercer", role: "Head of Product · Dune Analytics", accent: "#36C5F0" },
  { quote: "Every other tool made us work for it. Nudge works alongside us. The difference is felt on day one.", name: "Tomás Ruiz", role: "Engineering Manager · Fern", accent: "#2EB67D" },
  { quote: "I noticed our team stopped using Slack threads to track work. That said everything.", name: "Kira Johansson", role: "CTO · Luminara", accent: "#ECB22E" },
];

const plans = [
  { tier: "Solo", price: "0", cadence: "forever free", pitch: "Freelancers and side projects. No expiry.", lines: ["5 active projects", "Unlimited tasks", "Core views", "30-day history"], cta: "Start now", featured: false },
  { tier: "Team", price: "9", cadence: "per seat / month", pitch: "Every feature, no ceiling, no surprises.", lines: ["Unlimited everything", "Nudge AI engine", "All integrations", "Custom workflows", "Priority support"], cta: "Try free 14 days", featured: true },
  { tier: "Scale", price: "—", cadence: "custom", pitch: "For organisations that need control.", lines: ["SSO + SAML", "Advanced permissions", "Audit log", "Dedicated CSM", "99.9% SLA"], cta: "Talk to us", featured: false },
];

const faqs = [
  { q: "How is Nudge different?", a: "Most tools are passive — they store work and wait. Nudge is active: it watches what's stalling and prompts the right person at the right moment. One message, not thirty reminders." },
  { q: "How does the AI avoid being annoying?", a: "Each nudge is a single contextual message. The model learns your team's rhythm and only fires when a task has genuinely gone quiet beyond your normal cadence." },
  { q: "Can I migrate from another tool?", a: "Yes. One-click import from Jira, Asana, Linear, and Trello. All tasks, comments, attachments, and history come across in under 10 minutes." },
  { q: "Is there a free tier?", a: "Always. Solo covers freelancers and small projects indefinitely. No credit card, no trial clock." },
  { q: "How is pricing calculated?", a: "Per seat per month on Team. Add or remove seats anytime — you only pay for active users. Annual billing saves two months." },
];

/* ═══════════════════════════════════════════════════════════
   PAGE
═══════════════════════════════════════════════════════════ */
export default function Page() {
  const [navSolid, setNavSolid] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const heroRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress: heroScroll } = useScroll({ target: heroRef, offset: ["start start", "end start"] });
  const heroBgY = useTransform(heroScroll, [0, 1], ["0%", "25%"]);
  const heroOpacity = useTransform(heroScroll, [0, 0.85], [1, 0]);
  const heroScale = useTransform(heroScroll, [0, 1], [1, 0.97]);

  useEffect(() => {
    const fn = () => setNavSolid(window.scrollY > 40);
    window.addEventListener("scroll", fn);
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <>


      <ScrollBar />
      <Cursor />

      <main>

        {/* ── NAV ── */}
        <motion.header initial={{ y: -72, opacity: 0 }} animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
          style={{
            position: "fixed", top: 0, left: 0, right: 0, zIndex: 100, height: 68, display: "flex", alignItems: "center",
            background: navSolid ? "rgba(249,249,247,0.88)" : "transparent",
            backdropFilter: navSolid ? "blur(20px)" : "none",
            borderBottom: navSolid ? "1px solid rgba(0,0,0,0.05)" : "1px solid transparent",
            transition: "background 0.4s, border-color 0.4s"
          }}>
          <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 40px", width: "100%", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <NudgeLogo scale={0.72} />
            <nav style={{ display: "flex", gap: 36, alignItems: "center" }}>
              {["How it works", "Pricing", "FAQ"].map(l => (
                <motion.a key={l} href={`#${l.toLowerCase().replace(/ /g, "-")}`}
                  style={{ fontSize: 13, fontWeight: 600, color: "#6B7280" }}
                  whileHover={{ color: "#0D0D0D", y: -1 }} transition={{ duration: 0.15 }}>
                  {l}
                </motion.a>
              ))}
            </nav>
            <div className="flex items-center gap-2">
              <Link href="/sign-in">
                <motion.button
                  className="px-4 py-2 text-[13px] font-bold text-gray-500 transition-colors hover:text-[#0D0D0D] cursor-none"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Sign in
                </motion.button>
              </Link>

              <Link href="/get-started">
                <motion.button
                  className="px-4 py-2 text-[13px] font-bold text-white bg-[#0D0D0D] rounded-md transition-all hover:bg-black cursor-none"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Get started
                </motion.button>
              </Link>
            </div>
          </div>
        </motion.header>

        {/* ── HERO ── */}
        <section ref={heroRef} style={{ position: "relative", minHeight: "100vh", display: "flex", alignItems: "center", overflow: "hidden" }}>
          {/* Parallax blobs */}
          <motion.div style={{ y: heroBgY, position: "absolute", inset: 0, pointerEvents: "none" }}>
            <motion.div animate={{ scale: [1, 1.08, 1], rotate: [0, 6, 0] }} transition={{ duration: 14, repeat: Infinity, ease: "easeInOut" }}
              style={{ position: "absolute", top: "5%", left: "55%", width: 600, height: 500, borderRadius: "50%", background: "radial-gradient(ellipse,rgba(54,197,240,0.13) 0%,transparent 70%)", filter: "blur(40px)" }} />
            <motion.div animate={{ scale: [1, 1.05, 1], rotate: [0, -4, 0] }} transition={{ duration: 18, repeat: Infinity, ease: "easeInOut", delay: 3 }}
              style={{ position: "absolute", top: "40%", left: "10%", width: 500, height: 400, borderRadius: "50%", background: "radial-gradient(ellipse,rgba(46,182,125,0.09) 0%,transparent 70%)", filter: "blur(50px)" }} />
            <div style={{ position: "absolute", inset: 0, opacity: 0.35, backgroundImage: "radial-gradient(#c8c8c0 1px,transparent 1px)", backgroundSize: "28px 28px" }} />
          </motion.div>

          <motion.div style={{ opacity: heroOpacity, scale: heroScale, position: "relative", maxWidth: 1200, margin: "0 auto", padding: "100px 40px 100px", width: "100%" }}>
            {/* Badge */}


            {/* Headline word-by-word */}
            <h1 style={{ fontSize: "clamp(52px,7.5vw,96px)", fontWeight: 800, lineHeight: 1.0, letterSpacing: "-0.035em", color: "#0D0D0D", maxWidth: 860, marginBottom: 36 }}>
              {["The", "tool", "that", "actually", "moves", "your", "team", "forward."].map((w, i) => (
                <motion.span key={i} initial={{ opacity: 0, y: 40, filter: "blur(8px)" }}
                  animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                  transition={{ duration: 0.65, delay: 0.18 + i * 0.06, ease: [0.16, 1, 0.3, 1] }}
                  style={{ display: "inline-block", marginRight: "0.22em", color: w === "actually" ? "#36C5F0" : w === "forward." ? "#2EB67D" : "#0D0D0D" }}>
                  {w}
                </motion.span>
              ))}
            </h1>

            <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.7, ease: [0.16, 1, 0.3, 1] }}
              style={{ fontSize: 19, fontWeight: 400, color: "#6B7280", maxWidth: 520, lineHeight: 1.7, marginBottom: 52 }}>
              Nudge watches your work, finds what's stalling, and sends the one message that unsticks it. No noise. Just momentum.
            </motion.p>

            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.82, ease: [0.16, 1, 0.3, 1] }}
              style={{ display: "flex", gap: 16, alignItems: "center", flexWrap: "wrap", marginBottom: 88 }}>
              <MagBtn style={{ fontSize: 15, fontWeight: 800, color: "#fff", background: "#0D0D0D", border: "none", cursor: "none", padding: "17px 40px", borderRadius: 100, boxShadow: "0 4px 24px rgba(0,0,0,0.18)", letterSpacing: "0.01em" }}>
                Start free — no card needed
              </MagBtn>
              <motion.a href="#how-it-works" style={{ fontSize: 14, fontWeight: 600, color: "#36C5F0", display: "flex", alignItems: "center", gap: 6 }}
                whileHover={{ x: 4 }} transition={{ duration: 0.2 }}>
                See how it works <motion.span animate={{ x: [0, 5, 0] }} transition={{ duration: 1.4, repeat: Infinity }}>→</motion.span>
              </motion.a>
            </motion.div>

            {/* Count-up stats */}
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.8, delay: 1 }}
              style={{ display: "flex", gap: 56, flexWrap: "wrap", paddingTop: 48, borderTop: "1px solid #E8E8E2" }}>
              {[
                { val: 14000, suffix: "+", label: "Teams active", accent: "#36C5F0" },
                { val: 98, suffix: "%", label: "6-month retention", accent: "#2EB67D" },
                { val: 3, suffix: ".4×", label: "Faster resolution", accent: "#ECB22E" },
                { val: 0, suffix: "", label: "Unwanted pings", accent: "#E01E5A" },
              ].map((s, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.05 + i * 0.08 }}>
                  <div style={{ fontSize: 44, fontWeight: 800, letterSpacing: "-0.04em", color: s.accent, lineHeight: 1, fontFamily: "'Sora',sans-serif" }}>
                    {s.val === 14000 ? <><CountUp to={14} />k+</> : s.val === 3 ? <>3.4×</> : <><CountUp to={s.val} />{s.suffix}</>}
                  </div>
                  <div style={{ fontSize: 11, fontWeight: 600, color: "#9CA3AF", textTransform: "uppercase", letterSpacing: "0.12em", marginTop: 6 }}>{s.label}</div>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>
        </section>

        {/* ── DUAL TICKER ── */}
        <div style={{ background: "#0D0D0D", borderTop: "1px solid rgba(255,255,255,0.05)", borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
          <Ticker />
          <div style={{ borderTop: "1px solid rgba(255,255,255,0.04)" }}>
            <Ticker reverse />
          </div>
        </div>

        {/* ── STICKY FEATURES ── */}
        <div id="how-it-works" style={{ background: "#F9F9F7" }}>
          <StickyFeatures />
        </div>

        {/* ── HORIZONTAL SCROLL CARDS ── */}
        <div style={{ background: "#F9F9F7" }}>
          <HorizontalCards />
        </div>

        {/* ── SCROLL TEXT REVEAL ── */}
        <div style={{ background: "#F9F9F7", borderTop: "1px solid #EBEBEB", borderBottom: "1px solid #EBEBEB" }}>
          <ScrollTextReveal />
        </div>

        {/* ── TESTIMONIALS ── */}
        <section style={{ background: "#0D0D0D", padding: "120px 0", position: "relative", overflow: "hidden" }}>
          <motion.div animate={{ rotate: 360 }} transition={{ duration: 70, repeat: Infinity, ease: "linear" }}
            style={{ position: "absolute", top: "50%", left: "50%", width: 1000, height: 1000, borderRadius: "50%", border: "1px solid rgba(255,255,255,0.025)", transform: "translate(-50%,-50%)", pointerEvents: "none" }} />

          <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 40px" }}>
            <Reveal>
              <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 80 }}>
                <span style={{ width: 32, height: 2, background: "rgba(255,255,255,0.2)", display: "block" }} />
                <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.18em", textTransform: "uppercase", color: "rgba(255,255,255,0.3)" }}>Real teams</span>
              </div>
            </Reveal>
            <motion.div variants={{ hidden: {}, show: { transition: { staggerChildren: 0.12 } } }} initial="hidden" whileInView="show" viewport={{ once: true, margin: "-10%" }}
              style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(300px,1fr))", gap: 2 }}>
              {testimonials.map((t, i) => (
                <motion.div key={i} variants={{ hidden: { opacity: 0, y: 28 }, show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] } } }}
                  whileHover={{ background: "#161616", y: -4 }}
                  style={{ padding: "52px 44px", border: "1px solid rgba(255,255,255,0.05)", cursor: "default" }}>
                  <motion.div initial={{ scale: 0.6, opacity: 0 }} whileInView={{ scale: 1, opacity: 0.5 }} viewport={{ once: true }}
                    transition={{ delay: i * 0.1 + 0.2 }}
                    style={{ fontSize: 96, lineHeight: 0.7, color: t.accent, fontWeight: 800, marginBottom: 28 }}>"</motion.div>
                  <p style={{ fontSize: 17, fontWeight: 500, color: "rgba(255,255,255,0.82)", lineHeight: 1.7, marginBottom: 44 }}>{t.quote}</p>
                  <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                    <div style={{ width: 40, height: 40, borderRadius: "50%", background: t.accent, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 800, color: "#fff" }}>
                      {t.name.split(" ").map((n: string) => n[0]).join("")}
                    </div>
                    <div>
                      <p style={{ fontSize: 13, fontWeight: 700, color: "#fff" }}>{t.name}</p>
                      <p style={{ fontSize: 12, color: "rgba(255,255,255,0.3)", marginTop: 3 }}>{t.role}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* ── PRICING ── */}
        <section id="pricing" style={{ padding: "120px 0", background: "#F9F9F7" }}>
          <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 40px" }}>
            <Reveal>
              <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 20 }}>
                <span style={{ width: 32, height: 2, background: "#0D0D0D", display: "block" }} />
                <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.18em", textTransform: "uppercase" }}>Pricing</span>
              </div>
              <h2 style={{ fontSize: "clamp(40px,5vw,68px)", fontWeight: 800, letterSpacing: "-0.03em", marginBottom: 80, lineHeight: 1.05, maxWidth: 520 }}>Honest pricing.<br />No gotchas.</h2>
            </Reveal>
            <motion.div variants={{ hidden: {}, show: { transition: { staggerChildren: 0.1 } } }} initial="hidden" whileInView="show" viewport={{ once: true }}
              style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(280px,1fr))", gap: 20 }}>
              {plans.map((p, i) => (
                <motion.div key={i} variants={{ hidden: { opacity: 0, y: 32 }, show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] } } }}
                  whileHover={{ y: -6, boxShadow: p.featured ? "0 24px 64px rgba(0,0,0,0.3)" : "0 16px 48px rgba(0,0,0,0.1)" }}
                  style={{ padding: "48px 44px", background: p.featured ? "#0D0D0D" : "#fff", border: p.featured ? "none" : "1px solid #E8E8E2", borderRadius: 24, position: "relative", boxShadow: p.featured ? "0 12px 40px rgba(0,0,0,0.2)" : "0 2px 12px rgba(0,0,0,0.04)", cursor: "default" }}
                  transition={{ type: "spring", stiffness: 280, damping: 24 }}>
                  {p.featured && (
                    <motion.div initial={{ opacity: 0, scale: 0.7 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }}
                      style={{ position: "absolute", top: 20, right: 20, background: "#36C5F0", color: "#fff", fontSize: 10, fontWeight: 800, letterSpacing: "0.12em", textTransform: "uppercase", padding: "5px 14px", borderRadius: 100 }}>
                      Most popular
                    </motion.div>
                  )}
                  <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.16em", textTransform: "uppercase", color: p.featured ? "rgba(255,255,255,0.3)" : "#9CA3AF", marginBottom: 32 }}>{p.tier}</p>
                  <div style={{ display: "flex", alignItems: "baseline", gap: 4, marginBottom: 6 }}>
                    {p.price !== "—" && <span style={{ fontSize: 14, fontWeight: 700, color: p.featured ? "rgba(255,255,255,0.35)" : "#9CA3AF" }}>$</span>}
                    <span style={{ fontSize: 64, fontWeight: 800, letterSpacing: "-0.04em", color: p.featured ? "#fff" : "#0D0D0D", lineHeight: 1 }}>{p.price}</span>
                  </div>
                  <p style={{ fontSize: 12, color: p.featured ? "rgba(255,255,255,0.28)" : "#9CA3AF", marginBottom: 24 }}>{p.cadence}</p>
                  <p style={{ fontSize: 14, color: p.featured ? "rgba(255,255,255,0.5)" : "#6B7280", lineHeight: 1.6, marginBottom: 36, paddingBottom: 36, borderBottom: `1px solid ${p.featured ? "rgba(255,255,255,0.07)" : "#F0F0EC"}` }}>{p.pitch}</p>
                  <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: 16, marginBottom: 48 }}>
                    {p.lines.map((line, j) => (
                      <motion.li key={j} initial={{ opacity: 0, x: -8 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: j * 0.05 }}
                        style={{ display: "flex", alignItems: "center", gap: 12, fontSize: 14, fontWeight: 500, color: p.featured ? "rgba(255,255,255,0.72)" : "#374151" }}>
                        <span style={{ width: 20, height: 20, borderRadius: "50%", background: p.featured ? "rgba(54,197,240,0.12)" : "#F0FAF5", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                          <svg width="10" height="10" viewBox="0 0 10 10" fill="none"><path d="M2 5l2 2 4-4" stroke={p.featured ? "#36C5F0" : "#2EB67D"} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
                        </span>
                        {line}
                      </motion.li>
                    ))}
                  </ul>
                  <MagBtn style={{ width: "100%", padding: 15, borderRadius: 100, fontWeight: 800, fontSize: 14, cursor: "none", border: "none", background: p.featured ? "#36C5F0" : "#0D0D0D", color: "#fff" }}>
                    {p.cta}
                  </MagBtn>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* ── FAQ ── */}
        <section id="faq" style={{ background: "#F0F0EB", padding: "112px 0" }}>
          <div style={{ maxWidth: 740, margin: "0 auto", padding: "0 40px" }}>
            <Reveal>
              <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 20 }}>
                <span style={{ width: 32, height: 2, background: "#0D0D0D", display: "block" }} />
                <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.18em", textTransform: "uppercase" }}>FAQ</span>
              </div>
              <h2 style={{ fontSize: 52, fontWeight: 800, letterSpacing: "-0.03em", marginBottom: 64 }}>Good questions.</h2>
            </Reveal>
            {faqs.map((item, i) => (
              <Reveal key={i} delay={i * 0.04}>
                <div style={{ borderBottom: "1px solid #D8D8D0" }}>
                  <motion.button onClick={() => setOpenFaq(openFaq === i ? null : i)}
                    style={{ width: "100%", textAlign: "left", background: "none", border: "none", padding: "26px 0", display: "flex", justifyContent: "space-between", alignItems: "center", gap: 24, cursor: "none" }}
                    whileHover={{ x: 4 }} transition={{ duration: 0.15 }}>
                    <span style={{ fontSize: 16, fontWeight: 700, color: "#0D0D0D", lineHeight: 1.3 }}>{item.q}</span>
                    <motion.span animate={{ rotate: openFaq === i ? 45 : 0, background: openFaq === i ? "#0D0D0D" : "transparent" }} transition={{ duration: 0.2 }}
                      style={{ width: 30, height: 30, borderRadius: "50%", border: "1.5px solid #C8C8C0", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                      <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                        <path d="M6 2v8M2 6h8" stroke={openFaq === i ? "#fff" : "#9CA3AF"} strokeWidth="1.5" strokeLinecap="round" />
                      </svg>
                    </motion.span>
                  </motion.button>
                  <AnimatePresence>
                    {openFaq === i && (
                      <motion.p initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.32, ease: [0.16, 1, 0.3, 1] }}
                        style={{ fontSize: 15, color: "#6B7280", lineHeight: 1.75, paddingBottom: 28, overflow: "hidden" }}>
                        {item.a}
                      </motion.p>
                    )}
                  </AnimatePresence>
                </div>
              </Reveal>
            ))}
          </div>
        </section>

        {/* ── FINAL CTA ── */}
        <section style={{ background: "#0D0D0D", padding: "140px 0", position: "relative", overflow: "hidden" }}>
          <motion.div animate={{ scale: [1, 1.18, 1], opacity: [0.06, 0.11, 0.06] }} transition={{ duration: 9, repeat: Infinity, ease: "easeInOut" }}
            style={{ position: "absolute", top: "50%", left: "50%", width: 700, height: 500, borderRadius: "50%", background: "radial-gradient(ellipse,#36C5F0 0%,transparent 70%)", transform: "translate(-50%,-50%)", filter: "blur(60px)", pointerEvents: "none" }} />
          <div style={{ maxWidth: 760, margin: "0 auto", padding: "0 40px", textAlign: "center", position: "relative" }}>
            <Reveal>
              <div style={{ display: "flex", justifyContent: "center", marginBottom: 48 }}>
                <NudgeLogo scale={1.05} dark />
              </div>
              <h2 style={{ fontSize: "clamp(44px,7vw,80px)", fontWeight: 800, color: "#fff", letterSpacing: "-0.03em", lineHeight: 1.02, marginBottom: 28 }}>
                Your team is one<br />nudge away.
              </h2>
              <p style={{ fontSize: 17, color: "rgba(255,255,255,0.38)", lineHeight: 1.7, marginBottom: 56, maxWidth: 440, margin: "0 auto 56px" }}>
                14,000 teams ship faster. Start free — 3 minutes to onboard your whole team.
              </p>
              <MagBtn style={{ fontSize: 16, fontWeight: 800, color: "#0D0D0D", background: "#fff", border: "none", cursor: "none", padding: "20px 52px", borderRadius: 100, boxShadow: "0 4px 32px rgba(255,255,255,0.12)" }}>
                Start for free — no card needed
              </MagBtn>
              <p style={{ marginTop: 18, fontSize: 12, color: "rgba(255,255,255,0.18)" }}>Free forever on Solo · Cancel Team anytime</p>
            </Reveal>
          </div>
        </section>

        {/* ── FOOTER ── */}
        <footer style={{ background: "#0D0D0D", borderTop: "1px solid rgba(255,255,255,0.04)", padding: "36px 40px" }}>
          <div style={{ maxWidth: 1200, margin: "0 auto", display: "flex", flexWrap: "wrap", alignItems: "center", justifyContent: "space-between", gap: 20 }}>
            <NudgeLogo scale={0.6} dark />
            <div style={{ display: "flex", gap: 32 }}>
              {["Privacy", "Terms", "Changelog", "Status", "Blog"].map(l => (
                <motion.a key={l} href="#" style={{ fontSize: 13, fontWeight: 600, color: "rgba(255,255,255,0.2)" }}
                  whileHover={{ color: "rgba(255,255,255,0.7)" }} transition={{ duration: 0.15 }}>{l}</motion.a>
              ))}
            </div>
            <p style={{ fontSize: 12, color: "rgba(255,255,255,0.14)" }}>© 2026 Nudge Inc.</p>
          </div>
        </footer>

      </main>
    </>
  );
}