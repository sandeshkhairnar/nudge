"use client";

import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

/* ═══════════════════════════
   TYPES & DATA
═══════════════════════════ */
type Tab = "chat" | "tasks" | "team" | "resources";
type Message = { id: number; author: string; initials: string; color: string; text: string; time: string; isAI?: boolean };

const CHANNELS = [
  { id: "general",    label: "general",    unread: 0 },
  { id: "testing",    label: "testing",    unread: 3 },
  { id: "frontend",   label: "frontend",   unread: 0 },
  { id: "deployment", label: "deployment", unread: 1 },
  { id: "design",     label: "design",     unread: 0 },
];

const SEED: Record<string, Message[]> = {
  general: [
    { id: 1, author: "Ava M.",   initials: "AM", color: "#36C5F0", text: "Morning everyone! Q3 Launch is now at 72% ✅", time: "09:12" },
    { id: 2, author: "Tomás R.", initials: "TR", color: "#2EB67D", text: "API rate limiting PR is almost ready for review.", time: "09:18" },
    { id: 3, author: "Kira J.",  initials: "KJ", color: "#ECB22E", text: "Design tokens audit — pushing the last batch today.", time: "09:31" },
    { id: 4, author: "Sandesh",  initials: "S",  color: "#E01E5A", text: "Let's close 5 tasks before EOD 🚀", time: "09:45" },
    { id: 5, author: "Nudge AI", initials: "AI", color: "#7C3AED", text: "📌 'API rate limiting' stalled for 6 days. Want me to nudge Tomás?", time: "09:47", isAI: true },
    { id: 6, author: "Ava M.",   initials: "AM", color: "#36C5F0", text: "Yes please 😄", time: "09:48" },
    { id: 7, author: "Tomás R.", initials: "TR", color: "#2EB67D", text: "On it now! 💪", time: "09:49" },
  ],
  testing: [
    { id: 1, author: "Kira J.",  initials: "KJ", color: "#ECB22E", text: "Auth test suite passing — 42/42 green ✅", time: "10:02" },
    { id: 2, author: "Sandesh",  initials: "S",  color: "#E01E5A", text: "PDF export flaky on Firefox — tracking it.", time: "10:15" },
    { id: 3, author: "Nudge AI", initials: "AI", color: "#7C3AED", text: "📎 Testing sheet row #14 hasn't been updated in 4 days.", time: "10:16", isAI: true },
  ],
  frontend: [
    { id: 1, author: "Ava M.",   initials: "AM", color: "#36C5F0", text: "Onboarding v2 is in Figma — link in resources 👆", time: "11:00" },
    { id: 2, author: "Tomás R.", initials: "TR", color: "#2EB67D", text: "Will start implementing tomorrow.", time: "11:12" },
  ],
  deployment: [
    { id: 1, author: "Sandesh",  initials: "S",  color: "#E01E5A", text: "Staging deploy is live — all green on Vercel ✅", time: "15:04" },
  ],
  design: [
    { id: 1, author: "Kira J.",  initials: "KJ", color: "#ECB22E", text: "New component library uploaded to Figma.", time: "14:30" },
    { id: 2, author: "Ava M.",   initials: "AM", color: "#36C5F0", text: "Love the updated type scale 👏", time: "14:38" },
  ],
};

const RESOURCES = [
  { cat: "Documentation", icon: "📄", items: ["Project Docs", "API Reference", "Testing Sheet"] },
  { cat: "Credentials",   icon: "🔑", items: ["GitHub Repo", "Figma File"] },
  { cat: "Deployment",    icon: "🚀", items: ["Vercel Dashboard", "Staging URL"] },
  { cat: "Testing",       icon: "🧪", items: ["Test Cases", "Bug Tracker"] },
];

const TEAM = [
  { name: "Ava M.",    role: "Product Lead",   color: "#36C5F0", online: true },
  { name: "Tomás R.",  role: "Eng Manager",    color: "#2EB67D", online: true },
  { name: "Kira J.",   role: "QA Lead",        color: "#ECB22E", online: false },
  { name: "Sandesh",   role: "Full-stack Dev", color: "#E01E5A", online: true },
  { name: "Marcus W.", role: "Backend Dev",    color: "#A259FF", online: false },
  { name: "Priya N.",  role: "UI Designer",    color: "#FF6B6B", online: true },
];

const TASKS = [
  { title: "API rate limiting",   status: "in-progress", aColor: "#2EB67D", ai: "TR", age: 6, stalled: true  },
  { title: "Design tokens audit", status: "in-progress", aColor: "#ECB22E", ai: "KJ", age: 2, stalled: false },
  { title: "Onboarding flow v2",  status: "todo",        aColor: "#36C5F0", ai: "AM", age: 0, stalled: false },
  { title: "Auth refactor",       status: "review",      aColor: "#2EB67D", ai: "TR", age: 1, stalled: false },
  { title: "Dashboard analytics", status: "in-progress", aColor: "#E01E5A", ai: "S",  age: 3, stalled: false },
  { title: "PDF export fix",      status: "done",        aColor: "#A259FF", ai: "MW", age: 0, stalled: false },
];

const STATUS: Record<string, { label: string; bg: string; fg: string }> = {
  "todo":        { label: "To Do",       bg: "#F5F5F2", fg: "#9CA3AF" },
  "in-progress": { label: "In Progress", bg: "#EFF9FE", fg: "#36C5F0" },
  "review":      { label: "Review",      bg: "#FFFBEB", fg: "#D97706" },
  "done":        { label: "Done",        bg: "#ECFDF5", fg: "#059669" },
};

/* ═══════════════════════════
   AVATAR
═══════════════════════════ */
function Av({ i, c, sz = 28, online }: { i: string; c: string; sz?: number; online?: boolean }) {
  return (
    <div className="relative flex-shrink-0" style={{ width: sz, height: sz }}>
      <div className="w-full h-full rounded-full flex items-center justify-center font-black text-white"
        style={{ background: c, fontSize: sz * 0.36 }}>{i}</div>
      {online !== undefined && (
        <span className={`absolute -bottom-px -right-px w-2.5 h-2.5 rounded-full border-2 border-white ${online ? "bg-emerald-400" : "bg-gray-300"}`} />
      )}
    </div>
  );
}

/* ═══════════════════════════
   PAGE
═══════════════════════════ */
export default function SpacePage({ params }: { params?: { projectName?: string } }) {
  const raw     = params?.projectName ?? "nudge-ai";
  const display = raw.replace(/-/g, " ").replace(/\b\w/g, l => l.toUpperCase());

  const [channel, setChannel] = useState("general");
  const [tab,     setTab]     = useState<Tab>("chat");
  const [msgs,    setMsgs]    = useState(SEED);
  const [input,   setInput]   = useState("");
  const endRef = useRef<HTMLDivElement>(null);

  const curMsgs = msgs[channel] ?? [];
  const online  = TEAM.filter(m => m.online);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [channel, msgs]);

  function send() {
    if (!input.trim()) return;
    const m: Message = {
      id: Date.now(), author: "Sandesh", initials: "S", color: "#E01E5A",
      text: input.trim(),
      time: new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false }),
    };
    setMsgs(p => ({ ...p, [channel]: [...(p[channel] ?? []), m] }));
    setInput("");
  }

  return (
    /* This sits inside dashboard/layout.tsx's <main> — no extra wrapping needed */
    <div className="flex h-full overflow-hidden rounded-2xl border border-gray-100 shadow-sm bg-white" style={{ maxHeight: "calc(100vh - 116px)" }}>

      {/* ══════════════════════════════
          LEFT PANEL — nav + channels
      ══════════════════════════════ */}
      <div className="w-48 flex-shrink-0 flex flex-col bg-[#F9F9F7] border-r border-gray-100 overflow-hidden">

        {/* Project badge */}
        <div className="px-4 py-3.5 border-b border-gray-100 flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ background: "linear-gradient(135deg,#36C5F0,#2EB67D)" }}>
              <span className="text-white font-black text-[12px]">{display[0]}</span>
            </div>
            <div className="min-w-0">
              <p className="text-[12px] font-black text-gray-900 truncate leading-tight">{display}</p>
              <p className="text-[10px] text-gray-400 leading-tight">72% · sprint active</p>
            </div>
          </div>
        </div>

        {/* Section tabs */}
        <nav className="px-2.5 pt-3 space-y-0.5 flex-shrink-0">
          {([
            { id: "chat",      label: "Chat",      icon: "💬" },
            { id: "tasks",     label: "Tasks",     icon: "✅" },
            { id: "team",      label: "Team",      icon: "👥" },
            { id: "resources", label: "Resources", icon: "📁" },
          ] as { id: Tab; label: string; icon: string }[]).map(item => (
            <motion.button key={item.id} onClick={() => setTab(item.id)} whileHover={{ x: 1.5 }}
              className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg border-0 cursor-pointer transition-all text-left
                ${tab === item.id
                  ? "bg-white shadow-sm shadow-black/5 text-gray-900"
                  : "bg-transparent text-gray-400 hover:text-gray-600 hover:bg-white/60"}`}>
              <span className="text-[13px]">{item.icon}</span>
              <span className="text-[12.5px] font-semibold">{item.label}</span>
              {item.id === "chat" && tab !== "chat" && CHANNELS.reduce((s, c) => s + c.unread, 0) > 0 && (
                <span className="ml-auto w-4 h-4 rounded-full bg-[#36C5F0] text-white text-[9px] font-black flex items-center justify-center">
                  {CHANNELS.reduce((s, c) => s + c.unread, 0)}
                </span>
              )}
            </motion.button>
          ))}
        </nav>

        {/* Channels list (chat tab only) */}
        <AnimatePresence>
          {tab === "chat" && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }} transition={{ duration: 0.2 }}
              className="px-2.5 mt-4 overflow-hidden">
              <p className="text-[9px] font-black uppercase tracking-[0.14em] text-gray-300 px-2.5 mb-1.5">Channels</p>
              <div className="space-y-0.5">
                {CHANNELS.map(ch => (
                  <motion.button key={ch.id} onClick={() => setChannel(ch.id)} whileHover={{ x: 1.5 }}
                    className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg border-0 cursor-pointer transition-all
                      ${channel === ch.id && tab === "chat"
                        ? "bg-white shadow-sm text-gray-900"
                        : "bg-transparent text-gray-400 hover:text-gray-600"}`}>
                    <span className="text-[11px] text-gray-300 font-bold">#</span>
                    <span className="text-[12px] font-semibold flex-1 text-left truncate">{ch.label}</span>
                    {ch.unread > 0 && channel !== ch.id && (
                      <span className="w-3.5 h-3.5 rounded-full bg-[#36C5F0] text-white text-[8px] font-black flex items-center justify-center flex-shrink-0">
                        {ch.unread}
                      </span>
                    )}
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Online presence */}
        <div className="mt-auto px-4 py-3 border-t border-gray-100 flex-shrink-0">
          <p className="text-[9px] font-black uppercase tracking-[0.12em] text-gray-300 mb-2">Online · {online.length}</p>
          <div className="flex flex-wrap gap-1">
            {online.map((m, i) => (
              <Av key={i} i={m.name.split(" ").map(n => n[0]).join("").slice(0, 2)} c={m.color} sz={22} online />
            ))}
          </div>
        </div>
      </div>

      {/* ══════════════════════════════
          RIGHT PANEL — content
      ══════════════════════════════ */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">

        {/* Content topbar */}
        <div className="h-14 px-5 flex items-center justify-between border-b border-gray-100 flex-shrink-0 bg-white">
          <div className="flex items-center gap-2">
            {tab === "chat" && <span className="text-gray-200 font-bold text-[16px]">#</span>}
            <h2 className="text-[15px] font-black text-gray-900 capitalize">
              {tab === "chat" ? channel : tab}
            </h2>
            {tab === "chat" && (
              <span className="text-[12px] text-gray-300 font-medium ml-0.5">{curMsgs.length} messages</span>
            )}
          </div>
          <div className="flex items-center gap-2.5">
            <div className="flex -space-x-1.5">
              {online.slice(0, 4).map((m, i) => (
                <div key={i} className="ring-2 ring-white rounded-full">
                  <Av i={m.name.split(" ").map(n => n[0]).join("").slice(0, 2)} c={m.color} sz={24} />
                </div>
              ))}
            </div>
            <span className="text-[11px] text-gray-400 font-medium">{online.length} online</span>
          </div>
        </div>

        {/* Tab content */}
        <AnimatePresence mode="wait">
          <motion.div key={tab}
            initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
            className="flex-1 overflow-y-auto min-h-0">

            {/* ── CHAT ── */}
            {tab === "chat" && (
              <div className="px-5 py-3">
                {curMsgs.map((m, i) => {
                  const isNew = i === 0 || curMsgs[i - 1].author !== m.author;
                  return (
                    <div key={m.id} className={`flex gap-3 ${isNew ? "mt-4 first:mt-0" : "mt-0.5 pl-11"}`}>
                      {isNew && (
                        <div className="flex-shrink-0 pt-0.5">
                          <Av i={m.initials} c={m.color} sz={30} />
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        {isNew && (
                          <div className="flex items-baseline gap-2 mb-0.5">
                            <span className={`text-[13px] font-black ${m.isAI ? "text-violet-600" : "text-gray-900"}`}>{m.author}</span>
                            <span className="text-[11px] text-gray-300">{m.time}</span>
                            {m.isAI && <span className="text-[9px] font-black tracking-wider text-violet-500 bg-violet-50 border border-violet-100 px-1.5 py-0.5 rounded">AI</span>}
                          </div>
                        )}
                        <p className={`text-[13.5px] leading-relaxed ${m.isAI ? "bg-violet-50 border border-violet-100 text-violet-700 rounded-xl px-3.5 py-2 inline-block font-medium" : "text-gray-700"}`}>
                          {m.text}
                        </p>
                      </div>
                    </div>
                  );
                })}
                <div ref={endRef} className="h-4" />
              </div>
            )}

            {/* ── TASKS ── */}
            {tab === "tasks" && (
              <div className="p-5 space-y-2">
                {/* Summary row */}
                <div className="grid grid-cols-4 gap-3 mb-4">
                  {[
                    { label: "Total",       val: TASKS.length,                              color: "#0D0D0D" },
                    { label: "In Progress", val: TASKS.filter(t => t.status === "in-progress").length, color: "#36C5F0" },
                    { label: "Review",      val: TASKS.filter(t => t.status === "review").length,      color: "#D97706" },
                    { label: "Done",        val: TASKS.filter(t => t.status === "done").length,        color: "#059669" },
                  ].map((s, i) => (
                    <div key={i} className="bg-white border border-gray-100 rounded-xl px-4 py-3 text-center">
                      <p className="text-[22px] font-black" style={{ color: s.color }}>{s.val}</p>
                      <p className="text-[11px] text-gray-400 font-semibold">{s.label}</p>
                    </div>
                  ))}
                </div>

                {TASKS.map((t, i) => {
                  const s = STATUS[t.status];
                  return (
                    <motion.div key={i} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.04 }}
                      className="flex items-center gap-3 px-4 py-3 bg-white rounded-xl border border-gray-100 hover:border-gray-200 hover:shadow-sm transition-all group">
                      <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: s.fg }} />
                      <p className="flex-1 text-[13px] font-semibold text-gray-800 truncate">{t.title}</p>
                      {t.stalled && (
                        <span className="text-[10px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full flex-shrink-0">⚡ Stalled</span>
                      )}
                      <span className="text-[11px] font-bold px-2.5 py-1 rounded-full flex-shrink-0"
                        style={{ background: s.bg, color: s.fg }}>{s.label}</span>
                      <Av i={t.ai} c={t.aColor} sz={24} />
                      <span className="text-[11px] text-gray-300 w-9 text-right flex-shrink-0">
                        {t.age === 0 ? "Today" : `${t.age}d`}
                      </span>
                    </motion.div>
                  );
                })}
              </div>
            )}

            {/* ── TEAM ── */}
            {tab === "team" && (
              <div className="p-5">
                <div className="grid grid-cols-2 gap-3">
                  {TEAM.map((m, i) => (
                    <motion.div key={i} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="flex items-center gap-3 p-4 bg-white rounded-xl border border-gray-100 hover:border-gray-200 hover:shadow-sm transition-all">
                      <Av i={m.name.split(" ").map(n => n[0]).join("").slice(0, 2)} c={m.color} sz={38} online={m.online} />
                      <div className="min-w-0">
                        <p className="text-[13px] font-bold text-gray-900 truncate">{m.name}</p>
                        <p className="text-[11px] text-gray-400 truncate">{m.role}</p>
                        <p className={`text-[10px] font-semibold mt-0.5 ${m.online ? "text-emerald-500" : "text-gray-300"}`}>
                          {m.online ? "● Online" : "○ Away"}
                        </p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            )}

            {/* ── RESOURCES ── */}
            {tab === "resources" && (
              <div className="p-5 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  {RESOURCES.map((cat, ci) => (
                    <motion.div key={ci} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: ci * 0.06 }}
                      className="bg-white border border-gray-100 rounded-xl p-4 hover:border-gray-200 transition-all">
                      <div className="flex items-center gap-2 mb-3">
                        <span className="text-[15px]">{cat.icon}</span>
                        <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">{cat.cat}</span>
                      </div>
                      <div className="space-y-0.5">
                        {cat.items.map((item, ii) => (
                          <motion.a key={ii} href="#" whileHover={{ x: 3 }}
                            className="flex items-center justify-between group py-2 no-underline border-0 bg-transparent w-full text-left cursor-pointer">
                            <span className="text-[12.5px] font-semibold text-gray-700 group-hover:text-gray-900 transition-colors">{item}</span>
                            <span className="text-[11px] font-bold text-[#36C5F0] opacity-0 group-hover:opacity-100 transition-opacity">→</span>
                          </motion.a>
                        ))}
                      </div>
                    </motion.div>
                  ))}
                </div>

                {/* Quick links */}
                <div className="bg-white border border-gray-100 rounded-xl p-4">
                  <p className="text-[10px] font-black uppercase tracking-widest text-gray-300 mb-3">Quick Links</p>
                  <div className="flex flex-wrap gap-2">
                    {[
                      { l: "Figma",  e: "🎨" },
                      { l: "GitHub", e: "⌥"  },
                      { l: "Vercel", e: "▲"  },
                      { l: "Docs",   e: "📄" },
                    ].map((lk, i) => (
                      <motion.a key={i} href="#" whileHover={{ y: -2 }}
                        className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-gray-50 border border-gray-100 hover:border-gray-200 no-underline transition-all">
                        <span className="text-[12px]">{lk.e}</span>
                        <span className="text-[12px] font-semibold text-gray-600">{lk.l}</span>
                      </motion.a>
                    ))}
                  </div>
                </div>
              </div>
            )}

          </motion.div>
        </AnimatePresence>

        {/* Chat input */}
        {tab === "chat" && (
          <div className="flex-shrink-0 px-5 pb-4 pt-2 border-t border-gray-100 bg-white">
            <div className="flex items-center gap-3 bg-gray-50 border border-gray-150 rounded-2xl px-4 py-2.5 focus-within:bg-white focus-within:border-gray-200 transition-all"
              style={{ borderColor: "#EBEBEB" }}>
              <Av i="S" c="#E01E5A" sz={26} />
              <input value={input} onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === "Enter" && send()}
                placeholder={`Message #${channel}…`}
                className="flex-1 bg-transparent border-none outline-none text-[13px] font-medium text-gray-800 placeholder-gray-300" />
              <motion.button onClick={send} whileTap={{ scale: 0.95 }}
                className={`px-4 py-1.5 rounded-xl text-[12px] font-black border-0 cursor-pointer transition-all flex-shrink-0
                  ${input.trim() ? "bg-[#0D0D0D] text-white" : "bg-gray-100 text-gray-300"}`}>
                Send
              </motion.button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}