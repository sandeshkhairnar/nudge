"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Sidebar from "@/components/global/Sidebar";

function Topbar({ title }: { title?: string }) {
  const [search, setSearch] = useState("");
  const [focused, setFocused] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);

  const notifs = [
    { text: "API rate limiting stalled for 5 days", accent: "#ECB22E", time: "2m ago" },
    { text: "Kira left a comment on Auth refactor", accent: "#36C5F0", time: "14m ago" },
    { text: "Q3 Launch is 72% complete 🚀", accent: "#2EB67D", time: "1h ago" },
  ];

  return (
    <header className="h-[60px] border-b border-[#EBEBEB] flex items-center px-7 gap-4 bg-white shrink-0 sticky top-0 z-40">
      <div className="flex-1">
        <h1 className="text-[16px] font-extrabold text-[#0D0D0D] tracking-[-0.02em]">
          {title ?? "Dashboard"}
        </h1>
      </div>

      <motion.div
        animate={{
          width: focused ? 260 : 200,
          boxShadow: focused ? "0 0 0 2px #36C5F040" : "0 0 0 1px #EBEBEB",
        }}
        transition={{ duration: 0.2 }}
        className="rounded-[10px] bg-[#F9F9F7] flex items-center gap-2 px-3 h-9 overflow-hidden"
      >
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
          <circle cx="11" cy="11" r="7" stroke="#9CA3AF" strokeWidth="1.8" />
          <path d="M20 20l-3-3" stroke="#9CA3AF" strokeWidth="1.8" strokeLinecap="round" />
        </svg>

        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          placeholder="Search tasks…"
          className="bg-transparent border-none outline-none text-[13px] font-medium text-[#0D0D0D] w-full font-[Sora]"
        />

        {search && (
          <motion.button
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            onClick={() => setSearch("")}
            className="bg-none border-none text-[#9CA3AF] p-0 text-[14px] leading-none cursor-pointer"
          >
            ×
          </motion.button>
        )}
      </motion.div>

      <div className="relative">
        <motion.button
          whileHover={{ scale: 1.08 }}
          whileTap={{ scale: 0.94 }}
          onClick={() => setNotifOpen((o) => !o)}
          className="w-9 h-9 rounded-[10px] bg-[#F9F9F7] border border-[#EBEBEB] flex items-center justify-center relative cursor-pointer"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
            <path
              d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0"
              stroke="#374151"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>

          <span className="absolute top-[6px] right-[6px] w-[7px] h-[7px] rounded-full bg-[#E01E5A] border-[1.5px] border-white" />
        </motion.button>

        <AnimatePresence>
          {notifOpen && (
            <motion.div
              initial={{ opacity: 0, y: 8, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 6, scale: 0.96 }}
              transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
              className="absolute top-11 right-0 w-[320px] bg-white rounded-2xl border border-[#EBEBEB] shadow-[0_12px_40px_rgba(0,0,0,0.12)] overflow-hidden z-[99]"
            >
              <div className="px-5 pt-4 pb-[10px] flex justify-between items-center">
                <span className="text-[13px] font-extrabold text-[#0D0D0D]">
                  Notifications
                </span>
                <span className="text-[11px] font-bold text-[#36C5F0] cursor-pointer">
                  Mark all read
                </span>
              </div>

              {notifs.map((n, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.06 }}
                  whileHover={{ background: "#F9F9F7" }}
                  className="px-5 py-3 flex gap-3 cursor-pointer border-t border-[#F5F5F2]"
                >
                  <div
                    className="w-2 h-2 rounded-full mt-[5px] shrink-0"
                    style={{ background: n.accent }}
                  />
                  <div>
                    <p className="text-[13px] font-semibold text-[#374151] leading-[1.4] mb-[3px]">
                      {n.text}
                    </p>
                    <p className="text-[11px] text-[#9CA3AF]">{n.time}</p>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <motion.button
        whileHover={{ y: -1, boxShadow: "0 6px 20px rgba(0,0,0,0.18)" }}
        whileTap={{ scale: 0.96 }}
        className="h-9 px-4 bg-[#0D0D0D] text-white border-none rounded-[10px] text-[13px] font-extrabold cursor-pointer font-[Sora] flex items-center gap-[6px] whitespace-nowrap"
      >
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
          <path d="M12 5v14M5 12h14" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" />
        </svg>
        New task
      </motion.button>
    </header>
  );
}

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <Topbar />
        <main className="flex-1 overflow-y-auto overflow-x-hidden px-3 py-4 bg-[#F9F9F7]">
          {children}
        </main>
      </div>
    </div>
  );
}