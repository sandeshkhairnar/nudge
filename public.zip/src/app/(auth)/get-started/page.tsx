"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence, useMotionValue, useSpring } from "framer-motion";
import Link from "next/link";

/* ── LOGO ── */
function NudgeLogo({ dark = false }: { dark?: boolean }) {
  const id = `signup-pills-${dark ? "d" : "l"}`;
  return (
    <svg width="140" height="36" viewBox="0 0 220 56" fill="none">
      <g id={id}>
        <rect x="8" y="8" width="16" height="16" rx="8" fill="#36C5F0" />
        <rect x="8" y="26" width="16" height="16" rx="4" fill="#36C5F0" opacity="0.4" />
        <rect x="26" y="8" width="16" height="16" rx="4" fill="#2EB67D" opacity="0.4" />
        <rect x="26" y="26" width="16" height="16" rx="8" fill="#2EB67D" />
        <animateTransform href={`#${id}`} attributeName="transform" type="rotate"
          values="0 24 24;-30 24 24;-60 24 24;-90 24 24;-120 24 24;-150 24 24;-180 24 24;-210 24 24;-240 24 24;-270 24 24;-300 24 24;-330 24 24;-360 24 24"
          keyTimes="0;0.05;0.1;0.15;0.25;0.35;0.45;0.55;0.65;0.75;0.85;0.95;1"
          dur="6s" repeatCount="indefinite" />
      </g>
      <text x="56" y="37" fontFamily="'Sora',sans-serif" fontWeight="800" fontSize="28"
        fill={dark ? "#fff" : "#0D0D0D"} letterSpacing="-1">nudge</text>
    </svg>
  );
}

/* ── CURSOR GLOW ── */
function CursorGlow() {
  const mx = useMotionValue(-300); const my = useMotionValue(-300);
  const sx = useSpring(mx, { stiffness: 70, damping: 18 });
  const sy = useSpring(my, { stiffness: 70, damping: 18 });
  useEffect(() => {
    const fn = (e: MouseEvent) => { mx.set(e.clientX); my.set(e.clientY); };
    window.addEventListener("mousemove", fn);
    return () => window.removeEventListener("mousemove", fn);
  }, []);
  return (
    <motion.div style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0 }}>
      <motion.div style={{ position: "absolute", width: 500, height: 500, borderRadius: "50%", background: "radial-gradient(circle,rgba(46,182,125,0.06) 0%,transparent 70%)", x: sx, y: sy, translateX: "-50%", translateY: "-50%" }} />
    </motion.div>
  );
}

/* ── INPUT FIELD ── */
function Field({ label, type = "text", placeholder, value, onChange, error, hint }: any) {
  const [focused, setFocused] = useState(false);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <label style={{ fontSize: 12, fontWeight: 700, color: "#6B7280", letterSpacing: "0.06em", textTransform: "uppercase" }}>{label}</label>
        {hint && <span style={{ fontSize: 11, color: "#C4C4BC", fontWeight: 500 }}>{hint}</span>}
      </div>
      <motion.div
        animate={{ boxShadow: error ? "0 0 0 2px #E01E5A40" : focused ? "0 0 0 2px #2EB67D40" : "0 0 0 1px #E8E8E2" }}
        style={{ borderRadius: 12, background: "#fff" }}
        transition={{ duration: 0.2 }}
      >
        <input
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={e => onChange(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          style={{ width: "100%", padding: "14px 16px", background: "transparent", border: "none", outline: "none", fontSize: 15, fontFamily: "'Sora',sans-serif", fontWeight: 500, color: "#0D0D0D" }}
        />
      </motion.div>
      <AnimatePresence>
        {error && (
          <motion.p initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }}
            style={{ fontSize: 12, color: "#E01E5A", fontWeight: 600 }}>{error}</motion.p>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ── PASSWORD STRENGTH ── */
function PasswordStrength({ password }: { password: string }) {
  const strength = password.length === 0 ? 0 : password.length < 6 ? 1 : password.length < 10 ? 2 : /[A-Z]/.test(password) && /[0-9]/.test(password) ? 4 : 3;
  const labels = ["", "Weak", "Fair", "Good", "Strong"];
  const colors = ["", "#E01E5A", "#ECB22E", "#36C5F0", "#2EB67D"];
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      <div style={{ display: "flex", gap: 4 }}>
        {[1, 2, 3, 4].map(i => (
          <motion.div key={i}
            animate={{ background: i <= strength ? colors[strength] : "#E8E8E2" }}
            transition={{ duration: 0.3 }}
            style={{ flex: 1, height: 3, borderRadius: 2 }} />
        ))}
      </div>
      {password.length > 0 && (
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }}
          style={{ fontSize: 11, fontWeight: 700, color: colors[strength] }}>
          {labels[strength]}
        </motion.p>
      )}
    </div>
  );
}

/* ── STEPS INDICATOR ── */
function StepDots({ current, total }: { current: number; total: number }) {
  return (
    <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
      {Array.from({ length: total }).map((_, i) => (
        <motion.div key={i}
          animate={{ width: i === current ? 28 : 8, background: i === current ? "#2EB67D" : i < current ? "#2EB67D" : "#E8E8E2", opacity: i < current ? 0.5 : 1 }}
          style={{ height: 4, borderRadius: 2 }}
          transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }} />
      ))}
    </div>
  );
}

/* ── LEFT PANEL FEATURES ── */
const perks = [
  { icon: "⚡", text: "Up and running in 3 minutes" },
  { icon: "🧠", text: "AI that nudges stuck tasks forward" },
  { icon: "🎯", text: "One signal, not a wall of notifications" },
  { icon: "🔗", text: "Connects to Slack, GitHub, Figma" },
];

/* ── PAGE ── */
export default function SignupPage() {
  const [step, setStep] = useState(0); // 0 = account, 1 = workspace, 2 = done
  const [form, setForm] = useState({ name: "", email: "", password: "", workspace: "", role: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  const set = (key: string) => (val: string) => setForm(f => ({ ...f, [key]: val }));

  const validateStep0 = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = "Name is required";
    if (!form.email.includes("@")) e.email = "Enter a valid email";
    if (form.password.length < 6) e.password = "Must be at least 6 characters";
    return e;
  };

  const validateStep1 = () => {
    const e: Record<string, string> = {};
    if (!form.workspace.trim()) e.workspace = "Workspace name is required";
    return e;
  };

  const next = async () => {
    if (step === 0) {
      const e = validateStep0();
      if (Object.keys(e).length) { setErrors(e); return; }
      setErrors({});
      setStep(1);
    } else if (step === 1) {
      const e = validateStep1();
      if (Object.keys(e).length) { setErrors(e); return; }
      setErrors({});
      setLoading(true);
      await new Promise(r => setTimeout(r, 1600));
      setLoading(false);
      setStep(2);
    }
  };

  const roles = ["Engineer", "Product", "Design", "Marketing", "Operations", "Other"];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&display=swap');
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        html,body{height:100%;font-family:'Sora',sans-serif;background:#0D0D0D}
        input::placeholder{color:#C4C4BC}
        ::selection{background:#2EB67D;color:#fff}
        ::-webkit-scrollbar{width:4px}
        ::-webkit-scrollbar-track{background:#F0F0EB}
        ::-webkit-scrollbar-thumb{background:#D0D0C8;border-radius:4px}
      `}</style>

      <CursorGlow />

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", height: "100vh", position: "relative", zIndex: 1 }}>

        {/* ── LEFT PANEL ── */}
        <motion.div
          initial={{ x: -60, opacity: 0 }} animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          style={{ background: "#0D0D0D", display: "flex", flexDirection: "column", justifyContent: "space-between", padding: "52px 56px", position: "relative", overflow: "hidden" }}
        >
          {/* Blobs */}
          <motion.div animate={{ scale: [1, 1.1, 1], rotate: [0, -6, 0] }} transition={{ duration: 14, repeat: Infinity, ease: "easeInOut" }}
            style={{ position: "absolute", top: "-8%", right: "-8%", width: 420, height: 420, borderRadius: "50%", background: "radial-gradient(ellipse,rgba(46,182,125,0.1) 0%,transparent 70%)", filter: "blur(40px)", pointerEvents: "none" }} />
          <motion.div animate={{ scale: [1, 1.07, 1] }} transition={{ duration: 18, repeat: Infinity, ease: "easeInOut", delay: 5 }}
            style={{ position: "absolute", bottom: "8%", left: "-4%", width: 360, height: 280, borderRadius: "50%", background: "radial-gradient(ellipse,rgba(54,197,240,0.07) 0%,transparent 70%)", filter: "blur(50px)", pointerEvents: "none" }} />
          <div style={{ position: "absolute", inset: 0, backgroundImage: "radial-gradient(rgba(255,255,255,0.05) 1px,transparent 1px)", backgroundSize: "28px 28px", pointerEvents: "none" }} />

          {/* Logo */}
          <div style={{ position: "relative" }}>
            <NudgeLogo dark />
          </div>

          {/* Headline */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            style={{ position: "relative" }}>
            <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.16em", textTransform: "uppercase", color: "#2EB67D", display: "block", marginBottom: 16 }}>
              Free forever on Solo
            </span>
            <h2 style={{ fontSize: 36, fontWeight: 800, color: "#fff", letterSpacing: "-0.03em", lineHeight: 1.1, marginBottom: 12 }}>
              Start moving<br />faster today.
            </h2>
            <p style={{ fontSize: 15, color: "rgba(255,255,255,0.36)", lineHeight: 1.65, marginBottom: 44 }}>
              No credit card. No onboarding call.<br />Just your team and less chaos.
            </p>

            {/* Perks list */}
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              {perks.map((p, i) => (
                <motion.div key={i}
                  initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 + i * 0.08, duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
                  style={{ display: "flex", alignItems: "center", gap: 14 }}>
                  <span style={{ width: 36, height: 36, borderRadius: 10, background: "rgba(255,255,255,0.06)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0 }}>
                    {p.icon}
                  </span>
                  <span style={{ fontSize: 14, fontWeight: 600, color: "rgba(255,255,255,0.6)", lineHeight: 1.4 }}>{p.text}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Social proof */}
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.9 }}
            style={{ position: "relative", display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{ display: "flex" }}>
              {["#36C5F0","#2EB67D","#ECB22E","#E01E5A"].map((c, i) => (
                <div key={i} style={{ width: 28, height: 28, borderRadius: "50%", background: c, border: "2px solid #0D0D0D", marginLeft: i === 0 ? 0 : -8, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 800, color: "#fff" }}>
                  {String.fromCharCode(65 + i)}
                </div>
              ))}
            </div>
            <p style={{ fontSize: 12, color: "rgba(255,255,255,0.35)", fontWeight: 500, lineHeight: 1.4 }}>
              Joined by <strong style={{ color: "rgba(255,255,255,0.7)" }}>14,000+</strong><br />teams this year
            </p>
          </motion.div>
        </motion.div>

        {/* ── RIGHT PANEL ── */}
        <motion.div
          initial={{ x: 60, opacity: 0 }} animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          style={{ background: "#F9F9F7", display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", padding: "52px 64px", overflowY: "auto" }}
        >
          <div style={{ width: "100%", maxWidth: 400 }}>

            <AnimatePresence mode="wait">

              {/* ── STEP 0: Account ── */}
              {step === 0 && (
                <motion.div key="step0"
                  initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }}
                  transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}>
                  <div style={{ marginBottom: 36 }}>
                    <StepDots current={0} total={2} />
                    <h1 style={{ fontSize: 30, fontWeight: 800, color: "#0D0D0D", letterSpacing: "-0.03em", marginTop: 20, marginBottom: 6 }}>
                      Create your account
                    </h1>
                    <p style={{ fontSize: 14, color: "#6B7280", fontWeight: 500 }}>
                      Already have one?{" "}
                      <Link href="/login" style={{ color: "#36C5F0", fontWeight: 700 }}>Sign in →</Link>
                    </p>
                  </div>

                  {/* Social */}
                  <motion.button whileHover={{ y: -2, boxShadow: "0 6px 20px rgba(0,0,0,0.08)" }} whileTap={{ scale: 0.98 }}
                    style={{ width: "100%", padding: "13px 20px", background: "#fff", border: "1px solid #E8E8E2", borderRadius: 12, fontSize: 14, fontWeight: 700, color: "#0D0D0D", display: "flex", alignItems: "center", gap: 12, cursor: "pointer", fontFamily: "'Sora',sans-serif", boxShadow: "0 1px 4px rgba(0,0,0,0.05)", marginBottom: 24 }}>
                    <span style={{ width: 22, height: 22, borderRadius: 6, background: "#F0F0EB", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 800 }}>G</span>
                    Continue with Google
                  </motion.button>

                  <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 24 }}>
                    <div style={{ flex: 1, height: 1, background: "#E8E8E2" }} />
                    <span style={{ fontSize: 11, fontWeight: 700, color: "#C4C4BC", letterSpacing: "0.1em", textTransform: "uppercase" }}>or</span>
                    <div style={{ flex: 1, height: 1, background: "#E8E8E2" }} />
                  </div>

                  <div style={{ display: "flex", flexDirection: "column", gap: 18, marginBottom: 20 }}>
                    <Field label="Full name" placeholder="Alex Johnson" value={form.name} onChange={set("name")} error={errors.name} />
                    <Field label="Work email" type="email" placeholder="you@company.com" value={form.email} onChange={set("email")} error={errors.email} />
                    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                      <Field label="Password" type="password" placeholder="••••••••" value={form.password} onChange={set("password")} error={errors.password} hint="min. 6 characters" />
                      <PasswordStrength password={form.password} />
                    </div>
                  </div>

                  <motion.button onClick={next}
                    whileHover={{ y: -2, boxShadow: "0 8px 28px rgba(0,0,0,0.22)" }} whileTap={{ scale: 0.97 }}
                    style={{ width: "100%", padding: "15px", background: "#0D0D0D", color: "#fff", border: "none", borderRadius: 12, fontSize: 15, fontWeight: 800, cursor: "pointer", fontFamily: "'Sora',sans-serif", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, boxShadow: "0 4px 16px rgba(0,0,0,0.14)", marginTop: 4 }}>
                    Continue <span style={{ opacity: 0.5 }}>→</span>
                  </motion.button>
                </motion.div>
              )}

              {/* ── STEP 1: Workspace ── */}
              {step === 1 && (
                <motion.div key="step1"
                  initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }}
                  transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}>
                  <div style={{ marginBottom: 36 }}>
                    <StepDots current={1} total={2} />
                    <h1 style={{ fontSize: 30, fontWeight: 800, color: "#0D0D0D", letterSpacing: "-0.03em", marginTop: 20, marginBottom: 6 }}>
                      Set up your workspace
                    </h1>
                    <p style={{ fontSize: 14, color: "#6B7280", fontWeight: 500 }}>You can invite teammates next.</p>
                  </div>

                  <div style={{ display: "flex", flexDirection: "column", gap: 20, marginBottom: 24 }}>
                    <Field label="Workspace name" placeholder="Acme Inc." value={form.workspace} onChange={set("workspace")} error={errors.workspace} />

                    {/* Role selector */}
                    <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
                      <label style={{ fontSize: 12, fontWeight: 700, color: "#6B7280", letterSpacing: "0.06em", textTransform: "uppercase" }}>
                        Your role <span style={{ color: "#C4C4BC", fontWeight: 500, textTransform: "none", letterSpacing: 0 }}>(optional)</span>
                      </label>
                      <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                        {roles.map(r => (
                          <motion.button key={r} onClick={() => set("role")(r)}
                            whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.96 }}
                            animate={{
                              background: form.role === r ? "#0D0D0D" : "#fff",
                              color: form.role === r ? "#fff" : "#374151",
                              borderColor: form.role === r ? "#0D0D0D" : "#E8E8E2",
                            }}
                            transition={{ duration: 0.15 }}
                            style={{ padding: "8px 16px", borderRadius: 100, fontSize: 13, fontWeight: 600, border: "1px solid #E8E8E2", cursor: "pointer", fontFamily: "'Sora',sans-serif" }}>
                            {r}
                          </motion.button>
                        ))}
                      </div>
                    </div>

                    {/* Team size */}
                    <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
                      <label style={{ fontSize: 12, fontWeight: 700, color: "#6B7280", letterSpacing: "0.06em", textTransform: "uppercase" }}>Team size</label>
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                        {["Just me", "2–5", "6–20", "20+"].map(s => (
                          <motion.button key={s}
                            whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.97 }}
                            style={{ padding: "12px", background: "#fff", border: "1px solid #E8E8E2", borderRadius: 10, fontSize: 13, fontWeight: 600, color: "#374151", cursor: "pointer", fontFamily: "'Sora',sans-serif" }}>
                            {s}
                          </motion.button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div style={{ display: "flex", gap: 10 }}>
                    <motion.button onClick={() => setStep(0)}
                      whileHover={{ y: -1 }} whileTap={{ scale: 0.97 }}
                      style={{ flex: "0 0 auto", padding: "15px 20px", background: "#fff", border: "1px solid #E8E8E2", borderRadius: 12, fontSize: 15, fontWeight: 700, cursor: "pointer", color: "#6B7280", fontFamily: "'Sora',sans-serif" }}>
                      ←
                    </motion.button>
                    <motion.button onClick={next}
                      whileHover={{ y: -2, boxShadow: "0 8px 28px rgba(0,0,0,0.22)" }} whileTap={{ scale: 0.97 }}
                      style={{ flex: 1, padding: "15px", background: "#0D0D0D", color: "#fff", border: "none", borderRadius: 12, fontSize: 15, fontWeight: 800, cursor: "pointer", fontFamily: "'Sora',sans-serif", display: "flex", alignItems: "center", justifyContent: "center", gap: 10, boxShadow: "0 4px 16px rgba(0,0,0,0.14)" }}>
                      {loading ? (
                        <motion.div animate={{ rotate: 360 }} transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
                          style={{ width: 18, height: 18, borderRadius: "50%", border: "2.5px solid rgba(255,255,255,0.3)", borderTopColor: "#fff" }} />
                      ) : (
                        <>Create workspace <span style={{ opacity: 0.5 }}>→</span></>
                      )}
                    </motion.button>
                  </div>
                </motion.div>
              )}

              {/* ── STEP 2: Done ── */}
              {step === 2 && (
                <motion.div key="step2"
                  initial={{ opacity: 0, scale: 0.93 }} animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
                  style={{ textAlign: "center", padding: "20px 0" }}>
                  <motion.div initial={{ scale: 0, rotate: -20 }} animate={{ scale: 1, rotate: 0 }}
                    transition={{ type: "spring", stiffness: 180, delay: 0.1 }}
                    style={{ width: 80, height: 80, borderRadius: "50%", background: "#2EB67D", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 32px" }}>
                    <svg width="36" height="36" viewBox="0 0 36 36" fill="none">
                      <path d="M9 18l6 6 12-12" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </motion.div>

                  <motion.h2 initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}
                    style={{ fontSize: 28, fontWeight: 800, color: "#0D0D0D", letterSpacing: "-0.025em", marginBottom: 10 }}>
                    Welcome to nudge{form.workspace ? `, ${form.workspace}` : ""}!
                  </motion.h2>
                  <motion.p initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}
                    style={{ fontSize: 15, color: "#6B7280", lineHeight: 1.65, marginBottom: 40 }}>
                    Your workspace is ready.<br />Setting things up just for you…
                  </motion.p>

                  {/* Animated checklist */}
                  {["Account created", "Workspace initialised", "AI nudge engine ready"].map((item, i) => (
                    <motion.div key={i}
                      initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.4 + i * 0.18, duration: 0.4 }}
                      style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12, textAlign: "left" }}>
                      <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.5 + i * 0.18, type: "spring", stiffness: 200 }}
                        style={{ width: 24, height: 24, borderRadius: "50%", background: "#2EB67D", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                          <path d="M2.5 6l2.5 2.5 4.5-5" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      </motion.div>
                      <span style={{ fontSize: 14, fontWeight: 600, color: "#374151" }}>{item}</span>
                    </motion.div>
                  ))}

                  <motion.button initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1 }}
                    whileHover={{ y: -2, boxShadow: "0 8px 28px rgba(0,0,0,0.22)" }} whileTap={{ scale: 0.97 }}
                    style={{ width: "100%", marginTop: 32, padding: "15px", background: "#0D0D0D", color: "#fff", border: "none", borderRadius: 12, fontSize: 15, fontWeight: 800, cursor: "pointer", fontFamily: "'Sora',sans-serif", boxShadow: "0 4px 16px rgba(0,0,0,0.14)" }}>
                    Go to my workspace →
                  </motion.button>
                </motion.div>
              )}

            </AnimatePresence>

            {step < 2 && (
              <p style={{ marginTop: 36, fontSize: 11, color: "#C4C4BC", textAlign: "center", lineHeight: 1.6 }}>
                By continuing you agree to our{" "}
                <Link href="#" style={{ color: "#9CA3AF", fontWeight: 700 }}>Terms</Link>{" "}
                and{" "}
                <Link href="#" style={{ color: "#9CA3AF", fontWeight: 700 }}>Privacy Policy</Link>.
              </p>
            )}
          </div>
        </motion.div>
      </div>
    </>
  );
}