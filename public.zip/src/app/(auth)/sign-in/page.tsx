"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence, useMotionValue, useSpring } from "framer-motion";
import Link from "next/link";

/* ── LOGO ── */
function NudgeLogo({ dark = false }: { dark?: boolean }) {
  const id = `login-pills-${dark ? "d" : "l"}`;
  return (
    <svg width="140" height="36" viewBox="0 0 220 56" fill="none">
      <g id={id}>
        <rect x="8" y="8" width="16" height="16" rx="8" fill="#36C5F0" />
        <rect x="8" y="26" width="16" height="16" rx="4" fill="#36C5F0" opacity="0.4" />
        <rect x="26" y="8" width="16" height="16" rx="4" fill="#2EB67D" opacity="0.4" />
        <rect x="26" y="26" width="16" height="16" rx="8" fill="#2EB67D" />
        <animateTransform href={`#${id}`} attributeName="transform" type="rotate"
          values="0 24 24;-30 24 24;-60 24 24;-90 24 24;-120 24 24;-150 24 24;-180 24 24;-210 24 24;-240 24 24;-270 24 24;-300 24 24;-330 24 24;-360 24 24"
          keyTimes="0;0.05;0.1;0.15;0.25;0.35;0.45;0.55;0.65;0.75;0.85;0.95;1"
          dur="6s" repeatCount="indefinite" />
      </g>
      <text x="56" y="37" fontFamily="'Sora',sans-serif" fontWeight="800" fontSize="28"
        fill={dark ? "#fff" : "#0D0D0D"} letterSpacing="-1">nudge</text>
    </svg>
  );
}

/* ── FLOATING CURSOR GLOW ── */
function CursorGlow() {
  const mx = useMotionValue(-300); const my = useMotionValue(-300);
  const sx = useSpring(mx, { stiffness: 70, damping: 18 });
  const sy = useSpring(my, { stiffness: 70, damping: 18 });
  useEffect(() => {
    const fn = (e: MouseEvent) => { mx.set(e.clientX); my.set(e.clientY); };
    window.addEventListener("mousemove", fn);
    return () => window.removeEventListener("mousemove", fn);
  }, []);
  return (
    <motion.div style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0 }}>
      <motion.div style={{ position: "absolute", width: 480, height: 480, borderRadius: "50%", background: "radial-gradient(circle,rgba(54,197,240,0.06) 0%,transparent 70%)", x: sx, y: sy, translateX: "-50%", translateY: "-50%" }} />
    </motion.div>
  );
}

/* ── INPUT FIELD ── */
function Field({ label, type, placeholder, value, onChange, error }: any) {
  const [focused, setFocused] = useState(false);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
      <label style={{ fontSize: 12, fontWeight: 700, color: "#6B7280", letterSpacing: "0.06em", textTransform: "uppercase" }}>{label}</label>
      <motion.div
        animate={{ boxShadow: error ? "0 0 0 2px #E01E5A40" : focused ? "0 0 0 2px #36C5F040" : "0 0 0 1px #E8E8E2" }}
        style={{ borderRadius: 12, overflow: "hidden", background: "#fff" }}
        transition={{ duration: 0.2 }}
      >
        <input
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={e => onChange(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          style={{ width: "100%", padding: "14px 16px", background: "transparent", border: "none", outline: "none", fontSize: 15, fontFamily: "'Sora',sans-serif", fontWeight: 500, color: "#0D0D0D" }}
        />
      </motion.div>
      <AnimatePresence>
        {error && (
          <motion.p initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }}
            style={{ fontSize: 12, color: "#E01E5A", fontWeight: 600 }}>{error}</motion.p>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ── LEFT PANEL TESTIMONIAL QUOTES ── */
const quotes = [
  { text: "From messy threads to shipped features. Nudge changed how we work.", author: "Ava M.", role: "Head of Product" },
  { text: "The AI nudges feel like having a brilliant PM who never sleeps.", author: "Tomás R.", role: "Eng Manager" },
  { text: "We stopped losing things. That sounds small — it changed everything.", author: "Kira J.", role: "CTO" },
];

function RotatingQuote() {
  const [idx, setIdx] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setIdx(i => (i + 1) % quotes.length), 4000);
    return () => clearInterval(t);
  }, []);
  const q = quotes[idx];
  return (
    <AnimatePresence mode="wait">
      <motion.div key={idx}
        initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        style={{ maxWidth: 360 }}>
        <p style={{ fontSize: 20, fontWeight: 700, color: "#fff", lineHeight: 1.55, marginBottom: 20, letterSpacing: "-0.01em" }}>
          "{q.text}"
        </p>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 34, height: 34, borderRadius: "50%", background: "#36C5F0", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 800, color: "#fff" }}>
            {q.author[0]}
          </div>
          <div>
            <p style={{ fontSize: 13, fontWeight: 700, color: "#fff" }}>{q.author}</p>
            <p style={{ fontSize: 11, color: "rgba(255,255,255,0.4)" }}>{q.role}</p>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}

/* ── PAGE ── */
export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  const validate = () => {
    const e: Record<string, string> = {};
    if (!email.includes("@")) e.email = "Enter a valid email";
    if (password.length < 6) e.password = "Password must be 6+ characters";
    return e;
  };

  const submit = async () => {
    const e = validate();
    if (Object.keys(e).length) { setErrors(e); return; }
    setErrors({}); setLoading(true);
    await new Promise(r => setTimeout(r, 1400));
    setLoading(false); setDone(true);
  };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&display=swap');
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        html,body{height:100%;font-family:'Sora',sans-serif;background:#0D0D0D;overflow:hidden}
        input::placeholder{color:#C4C4BC}
        ::selection{background:#36C5F0;color:#fff}
      `}</style>

      <CursorGlow />

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", height: "100vh", position: "relative", zIndex: 1 }}>

        {/* ── LEFT PANEL ── */}
        <motion.div
          initial={{ x: -60, opacity: 0 }} animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          style={{ background: "#0D0D0D", display: "flex", flexDirection: "column", justifyContent: "space-between", padding: "52px 56px", position: "relative", overflow: "hidden" }}
        >
          {/* Animated blobs */}
          <motion.div animate={{ scale: [1, 1.12, 1], rotate: [0, 8, 0] }} transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
            style={{ position: "absolute", top: "-10%", right: "-10%", width: 400, height: 400, borderRadius: "50%", background: "radial-gradient(ellipse,rgba(54,197,240,0.1) 0%,transparent 70%)", filter: "blur(40px)", pointerEvents: "none" }} />
          <motion.div animate={{ scale: [1, 1.08, 1] }} transition={{ duration: 16, repeat: Infinity, ease: "easeInOut", delay: 4 }}
            style={{ position: "absolute", bottom: "5%", left: "-5%", width: 360, height: 300, borderRadius: "50%", background: "radial-gradient(ellipse,rgba(46,182,125,0.08) 0%,transparent 70%)", filter: "blur(50px)", pointerEvents: "none" }} />

          {/* Dot grid */}
          <div style={{ position: "absolute", inset: 0, backgroundImage: "radial-gradient(rgba(255,255,255,0.06) 1px,transparent 1px)", backgroundSize: "28px 28px", pointerEvents: "none" }} />

          {/* Logo */}
          <div style={{ position: "relative" }}>
            <NudgeLogo dark />
          </div>

          {/* Centre content */}
          <div style={{ position: "relative" }}>
            <motion.div
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
              style={{ marginBottom: 40 }}
            >
              <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.16em", textTransform: "uppercase", color: "#36C5F0", display: "block", marginBottom: 16 }}>
                14,000+ teams
              </span>
              <h2 style={{ fontSize: 36, fontWeight: 800, color: "#fff", letterSpacing: "-0.03em", lineHeight: 1.1, marginBottom: 12 }}>
                Good to have<br />you back.
              </h2>
              <p style={{ fontSize: 15, color: "rgba(255,255,255,0.38)", lineHeight: 1.65 }}>
                Your team has been busy.<br />Sign in to see what moved.
              </p>
            </motion.div>

            <RotatingQuote />
          </div>

          {/* Quote dots */}
          <div style={{ display: "flex", gap: 6, position: "relative" }}>
            {quotes.map((_, i) => (
              <motion.div key={i} style={{ height: 3, borderRadius: 2, background: "#fff" }}
                animate={{ width: i === 0 ? 24 : 8, opacity: i === 0 ? 1 : 0.2 }} />
            ))}
          </div>
        </motion.div>

        {/* ── RIGHT PANEL ── */}
        <motion.div
          initial={{ x: 60, opacity: 0 }} animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          style={{ background: "#F9F9F7", display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", padding: "52px 64px" }}
        >
          <div style={{ width: "100%", maxWidth: 400 }}>

            <AnimatePresence mode="wait">
              {done ? (
                <motion.div key="success"
                  initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
                  style={{ textAlign: "center", padding: "40px 0" }}>
                  <motion.div
                    initial={{ scale: 0 }} animate={{ scale: 1 }}
                    transition={{ type: "spring", stiffness: 200, delay: 0.1 }}
                    style={{ width: 72, height: 72, borderRadius: "50%", background: "#2EB67D", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 28px" }}>
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                      <path d="M7 16l6 6 12-12" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </motion.div>
                  <h3 style={{ fontSize: 24, fontWeight: 800, color: "#0D0D0D", marginBottom: 8, letterSpacing: "-0.02em" }}>You're in</h3>
                  <p style={{ fontSize: 14, color: "#6B7280" }}>Redirecting to your workspace…</p>
                </motion.div>
              ) : (
                <motion.div key="form" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                  {/* Header */}
                  <div style={{ marginBottom: 40 }}>
                    <h1 style={{ fontSize: 32, fontWeight: 800, color: "#0D0D0D", letterSpacing: "-0.03em", marginBottom: 8 }}>
                      Sign in
                    </h1>
                    <p style={{ fontSize: 14, color: "#6B7280", fontWeight: 500 }}>
                      No account?{" "}
                      <Link href="/get-started" style={{ color: "#36C5F0", fontWeight: 700 }}>
                        Create one free →
                      </Link>
                    </p>
                  </div>

                  {/* Social */}
                  <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 32 }}>
                    {[
                      { icon: "G", label: "Continue with Google", bg: "#fff", border: "#E8E8E2" },
                      { icon: "⌘", label: "Continue with SSO", bg: "#fff", border: "#E8E8E2" },
                    ].map((btn, i) => (
                      <motion.button key={i} whileHover={{ y: -2, boxShadow: "0 6px 20px rgba(0,0,0,0.08)" }} whileTap={{ scale: 0.98 }}
                        style={{ width: "100%", padding: "13px 20px", background: btn.bg, border: `1px solid ${btn.border}`, borderRadius: 12, fontSize: 14, fontWeight: 700, color: "#0D0D0D", display: "flex", alignItems: "center", gap: 12, cursor: "pointer", fontFamily: "'Sora',sans-serif", boxShadow: "0 1px 4px rgba(0,0,0,0.05)", transition: "box-shadow 0.2s" }}>
                        <span style={{ width: 22, height: 22, borderRadius: 6, background: "#F0F0EB", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 800 }}>{btn.icon}</span>
                        {btn.label}
                      </motion.button>
                    ))}
                  </div>

                  {/* Divider */}
                  <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 28 }}>
                    <div style={{ flex: 1, height: 1, background: "#E8E8E2" }} />
                    <span style={{ fontSize: 11, fontWeight: 700, color: "#C4C4BC", letterSpacing: "0.1em", textTransform: "uppercase" }}>or</span>
                    <div style={{ flex: 1, height: 1, background: "#E8E8E2" }} />
                  </div>

                  {/* Fields */}
                  <div style={{ display: "flex", flexDirection: "column", gap: 18, marginBottom: 28 }}>
                    <Field label="Email" type="email" placeholder="you@company.com" value={email} onChange={setEmail} error={errors.email} />
                    <Field label="Password" type="password" placeholder="••••••••" value={password} onChange={setPassword} error={errors.password} />
                  </div>

                  {/* Forgot */}
                  <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 28 }}>
                    <Link href="#" style={{ fontSize: 12, fontWeight: 700, color: "#9CA3AF" }}>Forgot password?</Link>
                  </div>

                  {/* Submit */}
                  <motion.button
                    onClick={submit}
                    whileHover={{ y: -2, boxShadow: "0 8px 28px rgba(0,0,0,0.22)" }}
                    whileTap={{ scale: 0.97 }}
                    style={{ width: "100%", padding: "15px", background: "#0D0D0D", color: "#fff", border: "none", borderRadius: 12, fontSize: 15, fontWeight: 800, cursor: "pointer", fontFamily: "'Sora',sans-serif", display: "flex", alignItems: "center", justifyContent: "center", gap: 10, boxShadow: "0 4px 16px rgba(0,0,0,0.14)", transition: "box-shadow 0.2s" }}
                  >
                    {loading ? (
                      <motion.div animate={{ rotate: 360 }} transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
                        style={{ width: 18, height: 18, borderRadius: "50%", border: "2.5px solid rgba(255,255,255,0.3)", borderTopColor: "#fff" }} />
                    ) : (
                      <>Sign in <span style={{ opacity: 0.5 }}>→</span></>
                    )}
                  </motion.button>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Footer */}
            <p style={{ marginTop: 40, fontSize: 11, color: "#C4C4BC", textAlign: "center", lineHeight: 1.6, fontWeight: 500 }}>
              By continuing you agree to our{" "}
              <Link href="#" style={{ color: "#9CA3AF", fontWeight: 700 }}>Terms</Link>{" "}
              and{" "}
              <Link href="#" style={{ color: "#9CA3AF", fontWeight: 700 }}>Privacy Policy</Link>.
            </p>
          </div>
        </motion.div>
      </div>
    </>
  );
}