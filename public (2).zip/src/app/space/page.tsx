"use client";

import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence, useInView } from "framer-motion";

/* ═══════════════════════════════════════════════
   HELPERS
═══════════════════════════════════════════════ */
function CountUp({ to, suffix = "", prefix = "" }: { to: number; suffix?: string; prefix?: string }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true });
  const [v, setV] = useState(0);
  useEffect(() => {
    if (!inView) return;
    const start = performance.now();
    const dur = 1400;
    const tick = (now: number) => {
      const p = Math.min((now - start) / dur, 1);
      const e = 1 - Math.pow(1 - p, 4);
      setV(Math.floor(e * to));
      if (p < 1) requestAnimationFrame(tick); else setV(to);
    };
    requestAnimationFrame(tick);
  }, [inView, to]);
  return <span ref={ref}>{prefix}{v.toLocaleString()}{suffix}</span>;
}

function Reveal({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-5% 0px" });
  return (
    <motion.div ref={ref} initial={{ opacity: 0, y: 20 }} animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.65, delay, ease: [0.16, 1, 0.3, 1] }}>
      {children}
    </motion.div>
  );
}

/* ═══════════════════════════════════════════════
   STAT CARD
═══════════════════════════════════════════════ */
/* ═══════════════════════════════════════════════
   STAT CARD - Stripe Style
═══════════════════════════════════════════════ */
function StatCard({ label, value, suffix = "", prefix = "", delta, accent, icon }: any) {
  const positive = delta >= 0;
  return (
    <motion.div
      whileHover={{ y: -2 }}
      style={{
        background: "#fff",
        borderRadius: 12,
        padding: "20px 20px 16px",
        border: "1px solid #F0F0F0",
        boxShadow: "0 1px 3px rgba(0,0,0,0.02), 0 1px 2px rgba(0,0,0,0.03)",
        cursor: "default",
        transition: "all 0.2s ease",
        position: "relative",
        overflow: "hidden"
      }}
    >
      {/* Subtle gradient overlay */}
      <div style={{
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        height: "3px",
        background: `linear-gradient(90deg, ${accent}40, ${accent})`
      }} />

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <span style={{
          fontSize: 12,
          fontWeight: 500,
          color: "#6B7280",
          textTransform: "uppercase",
          letterSpacing: "0.05em"
        }}>{label}</span>
        <div style={{
          width: 32,
          height: 32,
          borderRadius: 8,
          background: `${accent}08`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: accent,
          fontSize: 18
        }}>
          {icon}
        </div>
      </div>

      <div style={{
        fontSize: 32,
        fontWeight: 600,
        color: "#111827",
        letterSpacing: "-0.02em",
        lineHeight: 1.2,
        marginBottom: 8,
        fontFamily: "'Inter', 'Sora', sans-serif"
      }}>
        <CountUp to={value} suffix={suffix} prefix={prefix} />
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
        <span style={{
          fontSize: 12,
          fontWeight: 500,
          color: positive ? "#059669" : "#DC2626",
          background: positive ? "#ECFDF3" : "#FEF2F2",
          padding: "2px 8px",
          borderRadius: 16,
          display: "inline-flex",
          alignItems: "center",
          gap: 2
        }}>
          {positive ? "↑" : "↓"} {Math.abs(delta)}%
        </span>
        <span style={{ fontSize: 12, color: "#9CA3AF" }}>vs last week</span>
      </div>
    </motion.div>
  );
}

/* ═══════════════════════════════════════════════
   MINI SPARKLINE
═══════════════════════════════════════════════ */
function Sparkline({ data, color }: { data: number[]; color: string }) {
  const max = Math.max(...data); const min = Math.min(...data);
  const W = 80; const H = 28;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * W;
    const y = H - ((v - min) / (max - min || 1)) * H;
    return `${x},${y}`;
  }).join(" ");
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

/* ═══════════════════════════════════════════════
   VELOCITY BAR CHART
═══════════════════════════════════════════════ */
const velocityData = [
  { week: "W1", shipped: 8, stuck: 2 },
  { week: "W2", shipped: 12, stuck: 1 },
  { week: "W3", shipped: 7, stuck: 4 },
  { week: "W4", shipped: 16, stuck: 1 },
  { week: "W5", shipped: 14, stuck: 2 },
  { week: "W6", shipped: 19, stuck: 1 },
];

function VelocityChart() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true });
  const maxVal = Math.max(...velocityData.map(d => d.shipped + d.stuck));

  return (
    <div ref={ref} style={{ display: "flex", alignItems: "flex-end", gap: 10, height: 120, paddingTop: 10 }}>
      {velocityData.map((d, i) => (
        <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4, height: "100%", justifyContent: "flex-end" }}>
          <div style={{ width: "100%", display: "flex", flexDirection: "column", justifyContent: "flex-end", gap: 2, height: "100%" }}>
            <motion.div initial={{ height: 0 }} animate={inView ? { height: `${(d.stuck / maxVal) * 100}%` } : {}}
              transition={{ delay: 0.3 + i * 0.08, duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
              style={{ background: "#E01E5A", borderRadius: "3px 3px 0 0", minHeight: d.stuck > 0 ? 4 : 0, opacity: 0.7 }} />
            <motion.div initial={{ height: 0 }} animate={inView ? { height: `${(d.shipped / maxVal) * 100}%` } : {}}
              transition={{ delay: 0.2 + i * 0.08, duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
              style={{ background: "#2EB67D", borderRadius: "3px 3px 0 0" }} />
          </div>
          <span style={{ fontSize: 10, color: "#9CA3AF", fontWeight: 600 }}>{d.week}</span>
        </div>
      ))}
    </div>
  );
}

/* ═══════════════════════════════════════════════
   TASKS TABLE
═══════════════════════════════════════════════ */
const tasks = [
  { title: "API rate limiting", project: "API v2", assignee: "Marcus W.", status: "In Progress", priority: "high", age: 6, accent: "#ECB22E" },
  { title: "Design tokens audit", project: "Design System", assignee: "Kira J.", status: "In Progress", priority: "medium", age: 2, accent: "#36C5F0" },
  { title: "Onboarding flow v2", project: "Q3 Launch", assignee: "Ava M.", status: "To Do", priority: "high", age: 0, accent: "#E01E5A" },
  { title: "Auth refactor", project: "Auth Refactor", assignee: "Tomás R.", status: "Review", priority: "medium", age: 1, accent: "#2EB67D" },
  { title: "Dashboard analytics", project: "Q3 Launch", assignee: "Sandesh", status: "In Progress", priority: "low", age: 3, accent: "#A259FF" },
  { title: "PDF export fix", project: "API v2", assignee: "Marcus W.", status: "Done", priority: "low", age: 0, accent: "#2EB67D" },
    { title: "PDF export fix", project: "API v2", assignee: "Marcus W.", status: "Done", priority: "low", age: 0, accent: "#2EB67D" },

];

const statusColors: Record<string, { bg: string; text: string }> = {
  "To Do": { bg: "#F5F5F2", text: "#6B7280" },
  "In Progress": { bg: "#EFF9FE", text: "#36C5F0" },
  "Review": { bg: "#FFF8EC", text: "#ECB22E" },
  "Done": { bg: "#EDFBF4", text: "#2EB67D" },
};

const priorityDot: Record<string, string> = { high: "#E01E5A", medium: "#ECB22E", low: "#9CA3AF" };

function TaskRow({ task, index }: { task: typeof tasks[0]; index: number }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true });
  const s = statusColors[task.status];
  return (
    <motion.tr ref={ref}
      initial={{ opacity: 0, y: 8 }} animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ delay: index * 0.05, duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      whileHover={{ background: "#FAFAF8" }}
      style={{ cursor: "default" }}>
      <td style={{ padding: "12px 16px", fontSize: 13, fontWeight: 600, color: "#0D0D0D", display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{ width: 8, height: 8, borderRadius: "50%", background: task.accent, flexShrink: 0 }} />
        {task.title}
        {task.age >= 5 && (
          <motion.span animate={{ scale: [1, 1.1, 1] }} transition={{ duration: 2, repeat: Infinity }}
            style={{ fontSize: 10, fontWeight: 700, color: "#ECB22E", background: "#FFF8EC", padding: "2px 6px", borderRadius: 4 }}>
            ⚡ Nudge
          </motion.span>
        )}
      </td>
      <td style={{ padding: "12px 8px", fontSize: 12, color: "#6B7280", fontWeight: 500 }}>{task.project}</td>
      <td style={{ padding: "12px 8px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <div style={{ width: 22, height: 22, borderRadius: "50%", background: task.accent, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9, fontWeight: 800, color: "#fff", flexShrink: 0 }}>
            {task.assignee.split(" ").map(n => n[0]).join("")}
          </div>
          <span style={{ fontSize: 12, color: "#6B7280", fontWeight: 500 }}>{task.assignee}</span>
        </div>
      </td>
      <td style={{ padding: "12px 8px" }}>
        <span style={{ fontSize: 11, fontWeight: 700, color: s.text, background: s.bg, padding: "4px 10px", borderRadius: 100 }}>{task.status}</span>
      </td>
      <td style={{ padding: "12px 8px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
          <div style={{ width: 7, height: 7, borderRadius: "50%", background: priorityDot[task.priority] }} />
          <span style={{ fontSize: 12, color: "#9CA3AF", fontWeight: 600, textTransform: "capitalize" }}>{task.priority}</span>
        </div>
      </td>
      <td style={{ padding: "12px 16px", fontSize: 12, color: task.age >= 5 ? "#ECB22E" : "#9CA3AF", fontWeight: task.age >= 5 ? 700 : 500 }}>
        {task.age === 0 ? "Today" : `${task.age}d`}
      </td>
    </motion.tr>
  );
}

/* ═══════════════════════════════════════════════
   NUDGE FEED
═══════════════════════════════════════════════ */
const nudgeFeed = [
  { task: "API rate limiting", msg: "6 days with no updates. Want me to ping Marcus?", accent: "#ECB22E", time: "2m ago" },
  { task: "Onboarding flow v2", msg: "This task has no assignee and ships in 3 days.", accent: "#E01E5A", time: "18m ago" },
  { task: "Design System merge", msg: "PR has 3 unresolved review comments.", accent: "#36C5F0", time: "1h ago" },
];

/* ═══════════════════════════════════════════════
   DONUT PROGRESS
═══════════════════════════════════════════════ */
function DonutProgress({ value, color, size = 64 }: { value: number; color: string; size?: number }) {
  const r = (size - 10) / 2;
  const circ = 2 * Math.PI * r;
  const ref = useRef(null);
  const inView = useInView(ref, { once: true });
  return (
    <svg ref={ref} width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#F0F0EB" strokeWidth="8" />
      <motion.circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth="8"
        strokeLinecap="round" strokeDasharray={circ}
        initial={{ strokeDashoffset: circ }}
        animate={inView ? { strokeDashoffset: circ - (value / 100) * circ } : {}}
        transition={{ duration: 1, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
        style={{ transformOrigin: "center", transform: "rotate(-90deg)" }} />
      <text x={size / 2} y={size / 2 + 5} textAnchor="middle" fontSize="13" fontWeight="800" fill="#0D0D0D" fontFamily="'Sora',sans-serif">
        {value}%
      </text>
    </svg>
  );
}

/* ═══════════════════════════════════════════════
   PAGE
═══════════════════════════════════════════════ */
export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState<"all" | "mine" | "stuck">("all");

  const filtered = tasks.filter(t => {
    if (activeTab === "mine") return t.assignee === "Sandesh";
    if (activeTab === "stuck") return t.age >= 3;
    return true;
  });

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 28 }}>

      {/* ── GREETING ── */}
      <Reveal>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
          <div>
            <p style={{ fontSize: 13, color: "#9CA3AF", fontWeight: 600, marginBottom: 4 }}>
              {new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}
            </p>
            <h1 style={{ fontSize: 28, fontWeight: 800, color: "#0D0D0D", letterSpacing: "-0.025em" }}>
              Good morning, Sandesh 👋
            </h1>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8, background: "#FFF8EC", border: "1px solid #FDEBC8", borderRadius: 12, padding: "10px 16px" }}>
            <motion.div animate={{ scale: [1, 1.15, 1] }} transition={{ duration: 2, repeat: Infinity }}
              style={{ width: 8, height: 8, borderRadius: "50%", background: "#ECB22E" }} />
            <span style={{ fontSize: 13, fontWeight: 700, color: "#92400E" }}>2 tasks need a nudge</span>
          </div>
        </div>
      </Reveal>

      {/* ── STATS CARDS (Stripe Style) ── */}
      <div className="flex gap-6">
        {/* Stats Cards - 4 cards in a row */}
        <div className="flex-1 space-y-4">
          <motion.div
            variants={{ hidden: {}, show: { transition: { staggerChildren: 0.08 } } }}
            initial="hidden"
            animate="show"
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(4, 1fr)",
              gap: 16
            }}
          >
            {[
              { label: "Revenue", value: 54200, prefix: "$", delta: 12.5, accent: "#10B981", icon: "💰" },
              { label: "Customers", value: 2341, delta: 8.2, accent: "#3B82F6", icon: "👥" },
              { label: "Active", value: 19, delta: -2.4, accent: "#8B5CF6", icon: "⚡" },
              { label: "Tasks", value: 47, delta: 23.1, accent: "#F59E0B", icon: "✓" },
            ].map((s, i) => (
              <motion.div key={i} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0 } }}>
                <StatCard {...s} />
              </motion.div>
            ))}
          </motion.div>
          <Reveal delay={0.1}>
            <div style={{ background: "#fff", borderRadius: 16, border: "1px solid #EBEBEB", padding: "24px", boxShadow: "0 2px 8px rgba(0,0,0,0.04)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
                <div>
                  <h3 style={{ fontSize: 14, fontWeight: 800, color: "#0D0D0D", marginBottom: 2 }}>Team velocity</h3>
                  <p style={{ fontSize: 12, color: "#9CA3AF" }}>Last 6 sprints</p>
                </div>
                <div style={{ display: "flex", gap: 16 }}>
                  {[{ label: "Shipped", color: "#2EB67D" }, { label: "Stuck", color: "#E01E5A" }].map(l => (
                    <div key={l.label} style={{ display: "flex", alignItems: "center", gap: 6 }}>
                      <div style={{ width: 8, height: 8, borderRadius: 2, background: l.color }} />
                      <span style={{ fontSize: 11, color: "#9CA3AF", fontWeight: 600 }}>{l.label}</span>
                    </div>
                  ))}
                </div>
              </div>
              <VelocityChart />
            </div>
          </Reveal>
        </div>

        {/* Project health - fixed width on the right */}
        <div className="w-96">
          <Reveal delay={0.15}>
            <div style={{
              background: "#fff",
              borderRadius: 16,
              border: "1px solid #EBEBEB",
              padding: "24px",
              boxShadow: "0 2px 8px rgba(0,0,0,0.04)",
              height: "100%"
            }}>
              <h3 style={{ fontSize: 14, fontWeight: 800, color: "#0D0D0D", marginBottom: 20 }}>Project health</h3>
              <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
                {[
                  { name: "Q3 Launch", value: 72, color: "#36C5F0", tasks: 24 },
                  { name: "Auth Refactor", value: 45, color: "#2EB67D", tasks: 8 },
                  { name: "Design System", value: 88, color: "#ECB22E", tasks: 16 },
                  { name: "API v2", value: 20, color: "#E01E5A", tasks: 11 },
                  { name: "Deployment issues", value: 20, color: "#E01E5A", tasks: 11 },
                ].map((p, i) => {
                  const barRef = useRef(null);
                  const barInView = useInView(barRef, { once: true });
                  return (
                    <div key={i} ref={barRef} style={{ display: "flex", alignItems: "center", gap: 12 }}>
                      <DonutProgress value={p.value} color={p.color} size={44} />
                      <div style={{ flex: 1 }}>
                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                          <span style={{ fontSize: 13, fontWeight: 700, color: "#0D0D0D" }}>{p.name}</span>
                          <span style={{ fontSize: 11, color: "#9CA3AF" }}>{p.tasks} tasks</span>
                        </div>
                        <div style={{ height: 4, background: "#F0F0EB", borderRadius: 2, overflow: "hidden" }}>
                          <motion.div
                            initial={{ width: 0 }}
                            animate={barInView ? { width: `${p.value}%` } : {}}
                            transition={{ delay: 0.3 + i * 0.08, duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
                            style={{ height: "100%", background: p.color, borderRadius: 2 }}
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </Reveal>
        </div>
      </div>
      {/* ── CHARTS ROW ── */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: 20 }}>

        {/* Velocity chart */}
        <Reveal delay={0.1}>
          <div style={{ background: "#fff", borderRadius: 16, border: "1px solid #EBEBEB", overflow: "hidden", boxShadow: "0 2px 8px rgba(0,0,0,0.04)" }}>
            <div style={{ padding: "20px 20px 0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <h3 style={{ fontSize: 14, fontWeight: 800, color: "#0D0D0D" }}>Tasks</h3>
              {/* Tab filter */}
              <div style={{ display: "flex", background: "#F5F5F2", borderRadius: 8, padding: 3, gap: 2 }}>
                {(["all", "mine", "stuck"] as const).map(tab => (
                  <motion.button key={tab} onClick={() => setActiveTab(tab)}
                    style={{
                      padding: "5px 12px", borderRadius: 6, border: "none", cursor: "pointer", fontSize: 12, fontWeight: 700, fontFamily: "'Sora',sans-serif", position: "relative",
                      color: activeTab === tab ? "#0D0D0D" : "#9CA3AF",
                      background: "transparent"
                    }}>
                    {activeTab === tab && (
                      <motion.div layoutId="tab-bg" style={{ position: "absolute", inset: 0, background: "#fff", borderRadius: 6, boxShadow: "0 1px 4px rgba(0,0,0,0.08)" }} />
                    )}
                    <span style={{ position: "relative" }}>{tab.charAt(0).toUpperCase() + tab.slice(1)}</span>
                  </motion.button>
                ))}
              </div>
            </div>
            <table style={{ width: "100%", borderCollapse: "collapse", marginTop: 8 }}>
              <thead>
                <tr style={{ borderBottom: "1px solid #F0F0EB" }}>
                  {["Task", "Project", "Assignee", "Status", "Priority", "Age"].map(h => (
                    <th key={h} style={{ padding: "8px 16px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "#9CA3AF", textTransform: "uppercase", letterSpacing: "0.08em" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <AnimatePresence mode="popLayout">
                  {filtered.map((task, i) => (
                    <TaskRow key={task.title} task={task} index={i} />
                  ))}
                </AnimatePresence>
              </tbody>
            </table>
            {filtered.length === 0 && (
              <div style={{ padding: "40px", textAlign: "center", color: "#9CA3AF", fontSize: 14 }}>No tasks found</div>
            )}
          </div>
        </Reveal>

        <Reveal delay={0.18}>
          <div style={{ background: "#0D0D0D", borderRadius: 16, overflow: "hidden", boxShadow: "0 4px 20px rgba(0,0,0,0.14)", position: "relative" }}>
            <div style={{ position: "absolute", inset: 0, backgroundImage: "radial-gradient(rgba(255,255,255,0.04) 1px,transparent 1px)", backgroundSize: "20px 20px", pointerEvents: "none" }} />
            <div style={{ position: "relative", padding: "20px 20px 0" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 20 }}>
                <motion.div animate={{ scale: [1, 1.2, 1] }} transition={{ duration: 2, repeat: Infinity }}
                  style={{ width: 8, height: 8, borderRadius: "50%", background: "#36C5F0" }} />
                <h3 style={{ fontSize: 14, fontWeight: 800, color: "#fff" }}>Nudge feed</h3>
              </div>
            </div>
            <div style={{ position: "relative", padding: "0 0 20px" }}>
              {nudgeFeed.map((n, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + i * 0.1, duration: 0.5 }}
                  style={{ padding: "14px 20px", borderTop: i > 0 ? "1px solid rgba(255,255,255,0.06)" : "none" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                    <span style={{ fontSize: 12, fontWeight: 700, color: n.accent }}>{n.task}</span>
                    <span style={{ fontSize: 10, color: "rgba(255,255,255,0.25)" }}>{n.time}</span>
                  </div>
                  <p style={{ fontSize: 12, color: "rgba(255,255,255,0.55)", lineHeight: 1.5 }}>{n.msg}</p>
                  <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
                    <motion.button whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}
                      style={{ flex: 1, padding: "7px", background: n.accent, border: "none", borderRadius: 8, fontSize: 11, fontWeight: 800, color: "#fff", cursor: "pointer", fontFamily: "'Sora',sans-serif" }}>
                      Send nudge
                    </motion.button>
                    <motion.button whileHover={{ scale: 1.04 }}
                      style={{ padding: "7px 12px", background: "rgba(255,255,255,0.06)", border: "none", borderRadius: 8, fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.4)", cursor: "pointer", fontFamily: "'Sora',sans-serif" }}>
                      Dismiss
                    </motion.button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </div>
  );
}