"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  MessageSquare, Bell, Hash, ArrowRight, Reply, Check,
  CheckCheck, Loader2, Search, X, Send, Sparkles,
  AtSign, AlertCircle, Clock, Archive, Trash2, ChevronRight,
} from "lucide-react";
import Link from "next/link";
import { useNotifications, type Notification } from "@/hooks/useNotifications";
import { ToastContainer, ToastProps } from "@/components/global/toast";
import { useNotificationSound } from "@/hooks/useNotificationSound";

type NotifType = "mention" | "message" | "task" | "system";
type FilterTab = "all" | "mentions" | "messages" | "unread";

function colorFromString(s: string) {
  const palette = ["#36C5F0", "#2EB67D", "#ECB22E", "#E01E5A", "#A259FF", "#FF6B6B"];
  let h = 0;
  for (let i = 0; i < s.length; i++) h = s.charCodeAt(i) + ((h << 5) - h);
  return palette[Math.abs(h) % palette.length];
}

function initials(name: string | null | undefined) {
  if (!name) return "?";
  return name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase();
}

function relativeTime(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  if (d < 7) return `${d}d ago`;
  return new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

const TYPE_CONFIG: Record<NotifType, { icon: React.ReactNode; accent: string; label: string }> = {
  mention: { icon: <AtSign size={10} strokeWidth={2.5} />, accent: "#36C5F0", label: "Mention" },
  message: { icon: <MessageSquare size={10} strokeWidth={2.5} />, accent: "#2EB67D", label: "Message" },
  task: { icon: <AlertCircle size={10} strokeWidth={2.5} />, accent: "#ECB22E", label: "Task" },
  system: { icon: <Bell size={10} strokeWidth={2.5} />, accent: "#A259FF", label: "System" },
};

function Avatar({ name, userId, size = 36 }: { name: string | null | undefined; userId: string; size?: number }) {
  return (
    <div
      className="rounded-full flex items-center justify-center font-black text-white flex-shrink-0 select-none"
      style={{
        width: size,
        height: size,
        background: `linear-gradient(135deg, ${colorFromString(userId)}, ${colorFromString(userId + "x")})`,
        fontSize: size * 0.34,
        letterSpacing: "-0.5px",
      }}
    >
      {initials(name)}
    </div>
  );
}

function NotificationCard({
  notif,
  selected,
  onSelect,
  onMarkRead,
  onArchive,
}: {
  notif: Notification;
  selected: boolean;
  onSelect: () => void;
  onMarkRead: (id: string) => void;
  onArchive: (id: string) => void;
}) {
  const cfg = TYPE_CONFIG[notif.type];
  const [hovered, setHovered] = useState(false);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -16, transition: { duration: 0.18 } }}
      onClick={onSelect}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="relative flex gap-3 px-4 py-3.5 cursor-pointer transition-all duration-150 border-b"
      style={{
        background: selected
          ? `${cfg.accent}08`
          : hovered
          ? "rgba(0,0,0,0.018)"
          : "transparent",
        borderBottomColor: "rgba(0,0,0,0.05)",
        borderLeft: `2px solid ${selected ? cfg.accent : "transparent"}`,
      }}
    >
      {!notif.read && (
        <div
          className="absolute top-4 right-3.5 w-1.5 h-1.5 rounded-full"
          style={{ background: cfg.accent }}
        />
      )}

      <div className="flex-shrink-0 pt-0.5">
        {notif.sender ? (
          <Avatar name={notif.sender.full_name} userId={notif.sender.id} size={34} />
        ) : (
          <div
            className="w-[34px] h-[34px] rounded-full flex items-center justify-center flex-shrink-0"
            style={{ background: `${cfg.accent}12` }}
          >
            <span style={{ color: cfg.accent }}>{cfg.icon}</span>
          </div>
        )}
      </div>

      <div className="flex-1 min-w-0 pr-4">
        <div className="flex items-center gap-2 mb-0.5">
          <span className="text-[12.5px] font-black text-gray-900 truncate">
            {notif.sender?.full_name ?? "System"}
          </span>
          <span
            className="flex items-center gap-0.5 text-[8.5px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded-full flex-shrink-0"
            style={{ background: `${cfg.accent}12`, color: cfg.accent }}
          >
            {cfg.icon}
            <span className="ml-0.5">{cfg.label}</span>
          </span>
        </div>

        {(notif.project_name || notif.channel_name) && (
          <div className="flex items-center gap-0.5 mb-1">
            {notif.project_name && (
              <span className="text-[10px] font-semibold text-gray-400">{notif.project_name}</span>
            )}
            {notif.channel_name && (
              <>
                <ChevronRight size={8} className="text-gray-300 flex-shrink-0" />
                <Hash size={8} className="text-gray-400 flex-shrink-0" />
                <span className="text-[10px] font-semibold text-gray-400">{notif.channel_name}</span>
              </>
            )}
          </div>
        )}

        <p
          className="text-[12px] leading-relaxed line-clamp-2"
          style={{
            color: notif.read ? "#9CA3AF" : "#374151",
            fontWeight: notif.read ? 400 : 500,
          }}
        >
          {notif.preview}
        </p>

        <div className="flex items-center gap-1 mt-1">
          <Clock size={8} className="text-gray-300" />
          <span className="text-[10px] text-gray-400">{relativeTime(notif.created_at)}</span>
        </div>
      </div>

      <AnimatePresence>
        {hovered && (
          <motion.div
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.85 }}
            className="absolute right-2.5 bottom-2.5 flex items-center gap-1"
          >
            {!notif.read && (
              <button
                onClick={(e) => { e.stopPropagation(); onMarkRead(notif.id); }}
                title="Mark as read"
                className="w-6 h-6 rounded-md flex items-center justify-center border-0 bg-white shadow-sm text-gray-400 hover:text-emerald-500 cursor-pointer transition-colors"
                style={{ border: "1px solid rgba(0,0,0,0.07)" }}
              >
                <Check size={11} />
              </button>
            )}
            <button
              onClick={(e) => { e.stopPropagation(); onArchive(notif.id); }}
              title="Archive"
              className="w-6 h-6 rounded-md flex items-center justify-center border-0 bg-white shadow-sm text-gray-400 hover:text-red-400 cursor-pointer transition-colors"
              style={{ border: "1px solid rgba(0,0,0,0.07)" }}
            >
              <Archive size={11} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function ReplyComposer({
  notif,
  onSend,
  onClose,
}: {
  notif: Notification;
  onSend: (text: string) => Promise<void>;
  onClose: () => void;
}) {
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => { textareaRef.current?.focus(); }, []);

  const handleSend = async () => {
    if (!text.trim()) return;
    setSending(true);
    await onSend(text.trim());
    setText("");
    setSending(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl overflow-hidden bg-white"
      style={{
        border: "1px solid rgba(0,0,0,0.09)",
        boxShadow: "0 4px 24px rgba(0,0,0,0.06)",
      }}
    >
      <div className="px-4 py-2.5 flex items-center gap-2 border-b border-gray-100">
        <Reply size={12} className="text-gray-400" />
        <span className="text-[11px] font-semibold text-gray-400">
          Replying in {notif.channel_name ? `#${notif.channel_name}` : "thread"} · {notif.project_name ?? ""}
        </span>
        <button
          onClick={onClose}
          className="ml-auto text-gray-300 hover:text-gray-500 border-0 bg-transparent cursor-pointer flex items-center"
        >
          <X size={12} />
        </button>
      </div>
      <textarea
        ref={textareaRef}
        value={text}
        onChange={(e) => setText(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            handleSend();
          }
        }}
        placeholder="Write a reply… (Enter to send)"
        rows={3}
        className="w-full px-4 py-3 bg-transparent border-none outline-none text-[13px] font-medium text-gray-800 placeholder-gray-300 resize-none"
        style={{ fontFamily: "'Sora', sans-serif" }}
      />
      <div className="flex items-center justify-between px-3.5 pb-3 pt-1">
        <span className="text-[10px] text-gray-300">Shift+Enter for new line</span>
        <motion.button
          onClick={handleSend}
          whileTap={{ scale: 0.94 }}
          disabled={sending || !text.trim()}
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-[11.5px] font-black cursor-pointer border-0 transition-all disabled:opacity-40"
          style={{
            background: text.trim() && !sending ? "#0D0D0D" : "#F3F4F6",
            color: text.trim() && !sending ? "#fff" : "#9CA3AF",
            fontFamily: "'Sora', sans-serif",
          }}
        >
          {sending ? <Loader2 size={12} className="animate-spin" /> : <Send size={12} />}
          {sending ? "Sending…" : "Send"}
        </motion.button>
      </div>
    </motion.div>
  );
}

export default function InboxPage() {
  const [selected, setSelected] = useState<Notification | null>(null);
  const [filter, setFilter] = useState<FilterTab>("all");
  const [search, setSearch] = useState("");
  const [replying, setReplying] = useState(false);
  const [sentReplies, setSentReplies] = useState<Record<string, string[]>>({});
  const [toasts, setToasts] = useState<ToastProps[]>([]);

  const { playSound } = useNotificationSound();

  const handleNewNotification = useCallback(
    (notification: Notification) => {
      playSound(notification.type);

      const toast: ToastProps = {
        id: notification.id,
        type: notification.type,
        title: notification.sender?.full_name ?? "Nudge",
        message: notification.preview,
        projectName: notification.project_name ?? undefined,
        channelName: notification.channel_name ?? undefined,
        onClose: (id) => setToasts((prev) => prev.filter((t) => t.id !== id)),
        onClick: () => {
          setSelected(notification);
          setToasts((prev) => prev.filter((t) => t.id !== notification.id));
        },
      };

      setToasts((prev) => [toast, ...prev].slice(0, 5));
    },
    [playSound]
  );

  const {
    notifications,
    loading,
    unreadCount,
    markRead: handleMarkRead,
    markAllRead: handleMarkAllRead,
    archive: handleArchive,
  } = useNotifications({
    enableSound: true,
    enableToast: true,
    onNewNotification: handleNewNotification,
  });

  useEffect(() => {
    if (typeof window !== "undefined" && "Notification" in window) {
      if (Notification.permission === "default") {
        Notification.requestPermission();
      }
    }
  }, []);

  const filtered = notifications.filter((n) => {
    if (filter === "unread" && n.read) return false;
    if (filter === "mentions" && n.type !== "mention") return false;
    if (filter === "messages" && n.type !== "message") return false;
    if (
      search &&
      !n.content.toLowerCase().includes(search.toLowerCase()) &&
      !n.sender?.full_name?.toLowerCase().includes(search.toLowerCase()) &&
      !n.project_name?.toLowerCase().includes(search.toLowerCase())
    )
      return false;
    return true;
  });

  const handleSelect = (n: Notification) => {
    setSelected(n);
    setReplying(false);
    if (!n.read) handleMarkRead(n.id);
  };

  const handleArchiveAndDeselect = (id: string) => {
    if (selected?.id === id) {
      setSelected(null);
      setReplying(false);
    }
    handleArchive(id);
  };

  const handleSendReply = async (text: string) => {
    if (!selected) return;
    setSentReplies((prev) => ({
      ...prev,
      [selected.id]: [...(prev[selected.id] ?? []), text],
    }));
    setReplying(false);
  };

  const TABS: { id: FilterTab; label: string }[] = [
    { id: "all", label: "All" },
    { id: "unread", label: unreadCount ? `Unread · ${unreadCount}` : "Unread" },
    { id: "mentions", label: "Mentions" },
    { id: "messages", label: "Messages" },
  ];

  return (
    <>
      <div
        className="flex h-full overflow-hidden"
        style={{ fontFamily: "'Sora', sans-serif", background: "#F7F7F5" }}
      >
        <div
          className="flex flex-col border-r bg-white overflow-hidden flex-shrink-0"
          style={{
            width: selected ? 340 : "100%",
            maxWidth: 460,
            minWidth: 260,
            borderRightColor: "rgba(0,0,0,0.06)",
            transition: "width 0.25s cubic-bezier(0.16,1,0.3,1)",
          }}
        >
          <div className="px-5 pt-5 pb-3 flex-shrink-0 border-b" style={{ borderBottomColor: "rgba(0,0,0,0.05)" }}>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h1 className="text-[20px] font-black text-gray-900 tracking-tight">Inbox</h1>
                <p className="text-[11.5px] text-gray-400 mt-0.5">
                  {loading
                    ? "Loading…"
                    : unreadCount > 0
                    ? `${unreadCount} unread`
                    : "All caught up 🎉"}
                </p>
              </div>
              {unreadCount > 0 && (
                <motion.button
                  whileTap={{ scale: 0.96 }}
                  onClick={handleMarkAllRead}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-bold cursor-pointer transition-colors border-0"
                  style={{
                    background: "rgba(0,0,0,0.04)",
                    color: "#6B7280",
                    fontFamily: "'Sora', sans-serif",
                  }}
                >
                  <CheckCheck size={11} />
                  Mark all read
                </motion.button>
              )}
            </div>

            <div className="relative mb-3">
              <Search size={12} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-300" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search notifications…"
                className="w-full pl-8 pr-8 py-2 rounded-xl text-[12px] text-gray-700 placeholder-gray-300 outline-none transition-all"
                style={{
                  background: "rgba(0,0,0,0.04)",
                  border: "1px solid transparent",
                  fontFamily: "'Sora', sans-serif",
                }}
                onFocus={(e) => (e.target.style.borderColor = "rgba(0,0,0,0.1)")}
                onBlur={(e) => (e.target.style.borderColor = "transparent")}
              />
              {search && (
                <button
                  onClick={() => setSearch("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-300 hover:text-gray-500 border-0 bg-transparent cursor-pointer"
                >
                  <X size={11} />
                </button>
              )}
            </div>

            <div className="flex gap-0.5">
              {TABS.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setFilter(t.id)}
                  className="px-3 py-1.5 rounded-lg text-[11px] font-bold cursor-pointer border-0 transition-all"
                  style={{
                    background: filter === t.id ? "#0D0D0D" : "transparent",
                    color: filter === t.id ? "#fff" : "#9CA3AF",
                    fontFamily: "'Sora', sans-serif",
                  }}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex-1 overflow-y-auto">
            {loading ? (
              <div className="flex items-center justify-center h-40">
                <Loader2 size={18} className="animate-spin text-gray-300" />
              </div>
            ) : (
              <AnimatePresence mode="popLayout">
                {filtered.length === 0 ? (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex flex-col items-center justify-center h-48 gap-2"
                  >
                    <div className="w-10 h-10 rounded-2xl bg-gray-50 flex items-center justify-center">
                      <Bell size={18} className="text-gray-300" />
                    </div>
                    <p className="text-[12.5px] font-semibold text-gray-400">No notifications</p>
                  </motion.div>
                ) : (
                  filtered.map((n) => (
                    <NotificationCard
                      key={n.id}
                      notif={n}
                      selected={selected?.id === n.id}
                      onSelect={() => handleSelect(n)}
                      onMarkRead={handleMarkRead}
                      onArchive={handleArchiveAndDeselect}
                    />
                  ))
                )}
              </AnimatePresence>
            )}
          </div>
        </div>

        <AnimatePresence>
          {selected && (
            <motion.div
              initial={{ opacity: 0, x: 16 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 16 }}
              transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
              className="flex-1 flex flex-col overflow-hidden"
              style={{ background: "#F7F7F5" }}
            >
              <div
                className="flex-shrink-0 px-5 py-3.5 bg-white flex items-center justify-between border-b"
                style={{ borderBottomColor: "rgba(0,0,0,0.05)" }}
              >
                <div className="flex items-center gap-3">
                  {selected.sender ? (
                    <Avatar name={selected.sender.full_name} userId={selected.sender.id} size={36} />
                  ) : (
                    <div className="w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center">
                      <Bell size={15} className="text-gray-400" />
                    </div>
                  )}
                  <div>
                    <p className="text-[13px] font-black text-gray-900">
                      {selected.sender?.full_name ?? "System"}
                    </p>
                    <div className="flex items-center gap-1 text-[10.5px] text-gray-400 mt-0.5">
                      {selected.project_name && <span>{selected.project_name}</span>}
                      {selected.channel_name && (
                        <>
                          <ChevronRight size={9} className="text-gray-300" />
                          <Hash size={9} />
                          <span>{selected.channel_name}</span>
                        </>
                      )}
                      <span className="mx-0.5 text-gray-300">·</span>
                      <Clock size={9} />
                      <span>{relativeTime(selected.created_at)}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  {selected.project_id && selected.channel_id && (
                    <Link href={`/space/${selected.project_id}`}>
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.97 }}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11.5px] font-bold border-0 text-white cursor-pointer"
                        style={{ background: "#0D0D0D", fontFamily: "'Sora', sans-serif" }}
                      >
                        Open in Chat
                        <ArrowRight size={11} />
                      </motion.button>
                    </Link>
                  )}
                  <button
                    onClick={() => handleArchiveAndDeselect(selected.id)}
                    className="w-7 h-7 rounded-lg flex items-center justify-center border text-gray-400 hover:text-red-400 cursor-pointer transition-colors bg-white"
                    style={{ borderColor: "rgba(0,0,0,0.08)" }}
                  >
                    <Trash2 size={13} />
                  </button>
                  <button
                    onClick={() => { setSelected(null); setReplying(false); }}
                    className="w-7 h-7 rounded-lg flex items-center justify-center border text-gray-400 hover:text-gray-600 cursor-pointer transition-colors bg-white"
                    style={{ borderColor: "rgba(0,0,0,0.08)" }}
                  >
                    <X size={13} />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto px-5 py-5">
                <div className="max-w-xl">
                  <div className="flex gap-3 mb-5">
                    {selected.sender ? (
                      <Avatar name={selected.sender.full_name} userId={selected.sender.id} size={32} />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0">
                        <Sparkles size={13} className="text-gray-400" />
                      </div>
                    )}
                    <div className="flex-1">
                      <div className="flex items-baseline gap-2 mb-1.5">
                        <span className="text-[12.5px] font-black text-gray-900">
                          {selected.sender?.full_name ?? "Nudge"}
                        </span>
                        <span className="text-[10.5px] text-gray-400">{relativeTime(selected.created_at)}</span>
                      </div>
                      <div
                        className="bg-white rounded-2xl rounded-tl-sm px-4 py-3"
                        style={{
                          border: "1px solid rgba(0,0,0,0.06)",
                          boxShadow: "0 1px 4px rgba(0,0,0,0.04)",
                        }}
                      >
                        <p className="text-[13.5px] text-gray-800 leading-relaxed">{selected.content}</p>
                      </div>
                    </div>
                  </div>

                  {(sentReplies[selected.id] ?? []).map((reply, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex gap-3 mb-4 flex-row-reverse"
                    >
                      <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-[10px] font-black text-white"
                        style={{ background: "linear-gradient(135deg,#36C5F0,#2EB67D)" }}>
                        You
                      </div>
                      <div className="flex-1 flex flex-col items-end">
                        <div className="flex items-baseline gap-2 mb-1.5">
                          <span className="text-[10.5px] text-gray-400">just now</span>
                          <span className="text-[12.5px] font-black text-gray-900">You</span>
                        </div>
                        <div className="bg-gray-900 rounded-2xl rounded-tr-sm px-4 py-3 max-w-sm">
                          <p className="text-[13.5px] text-white leading-relaxed">{reply}</p>
                        </div>
                        <div className="flex items-center gap-1 mt-1.5">
                          <CheckCheck size={10} className="text-emerald-400" />
                          <span className="text-[10px] text-gray-400">
                            Sent{selected.channel_name ? ` to #${selected.channel_name}` : ""}
                          </span>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>

              <div className="flex-shrink-0 px-5 pb-5 pt-2">
                <AnimatePresence mode="wait">
                  {replying ? (
                    <ReplyComposer
                      key="composer"
                      notif={selected}
                      onSend={handleSendReply}
                      onClose={() => setReplying(false)}
                    />
                  ) : (
                    <motion.div
                      key="actions"
                      initial={{ opacity: 0, y: 4 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex items-center gap-2 flex-wrap"
                    >
                      {selected.channel_id && (
                        <button
                          onClick={() => setReplying(true)}
                          className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-[12.5px] font-bold border-0 text-white cursor-pointer"
                          style={{ background: "#0D0D0D", fontFamily: "'Sora', sans-serif" }}
                        >
                          <Reply size={13} />
                          Reply
                        </button>
                      )}
                      {selected.project_id && (
                        <Link href={`/space/${selected.project_id}`}>
                          <button
                            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-[12.5px] font-bold text-gray-700 hover:bg-gray-100 cursor-pointer transition-colors bg-white"
                            style={{
                              border: "1px solid rgba(0,0,0,0.08)",
                              fontFamily: "'Sora', sans-serif",
                            }}
                          >
                            <ArrowRight size={13} />
                            Go to Project
                          </button>
                        </Link>
                      )}
                      {!selected.read && (
                        <button
                          onClick={() => handleMarkRead(selected.id)}
                          className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-[12.5px] font-bold text-gray-500 hover:bg-gray-100 cursor-pointer transition-colors bg-white"
                          style={{
                            border: "1px solid rgba(0,0,0,0.08)",
                            fontFamily: "'Sora', sans-serif",
                          }}
                        >
                          <Check size={13} />
                          Mark read
                        </button>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {!selected && (
          <div className="hidden lg:flex flex-1 items-center justify-center flex-col gap-3">
            <motion.div
              initial={{ scale: 0.92, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.1 }}
              className="flex flex-col items-center"
            >
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center mb-3 bg-white"
                style={{ border: "1px solid rgba(0,0,0,0.07)", boxShadow: "0 2px 12px rgba(0,0,0,0.06)" }}
              >
                <MessageSquare size={22} className="text-gray-300" />
              </div>
              <p className="text-[13.5px] font-bold text-gray-400">Select a notification</p>
              <p className="text-[11.5px] text-gray-300 mt-0.5">to read and reply</p>
            </motion.div>
          </div>
        )}
      </div>

      <ToastContainer toasts={toasts} onClose={(id) => setToasts((prev) => prev.filter((t) => t.id !== id))} />
    </>
  );
}