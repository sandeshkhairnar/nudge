"use client";

import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { createClient } from "@/lib/supabase/client";
import { useNotificationSound } from "@/hooks/useNotificationSound";
import { ToastContainer, ToastProps } from "@/components/global/toast";
import { usePathname } from "next/navigation";

interface Notification {
  id: string;
  type: "mention" | "message" | "task" | "system";
  read: boolean;
  created_at: string;
  project_id: string | null;
  channel_id: string | null;
  project_name: string | null;
  channel_name: string | null;
  sender: {
    id: string;
    full_name: string | null;
    avatar_url: string | null;
  } | null;
  content: string;
  preview: string;
}

interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  markAsRead: (id: string) => Promise<void>;
  markAllAsRead: () => Promise<void>;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export function useNotifications() {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error("useNotifications must be used within a NotificationProvider");
  }
  return context;
}

export function NotificationProvider({ children }: { children: ReactNode }) {
  const supabase = createClient();
  const pathname = usePathname();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [toasts, setToasts] = useState<ToastProps[]>([]);
  const [userId, setUserId] = useState<string | null>(null);
  const { playSound } = useNotificationSound();

  const isInboxPage = pathname === "/space/inbox";

  useEffect(() => {
    const fetchUserAndNotifications = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      setUserId(user.id);

      const { data } = await supabase
        .from("notifications")
        .select(`
          id, type, read, created_at,
          project_id, channel_id, message_id,
          content, preview,
          sender:profiles!notifications_sender_id_fkey (
            id, full_name, avatar_url
          ),
          project:projects ( name ),
          channel:channels ( name )
        `)
        .eq("recipient_id", user.id)
        .order("created_at", { ascending: false })
        .limit(50);

      if (data) {
        const shaped = data.map((n: any) => ({
          ...n,
          sender: n.sender ?? null,
          project_name: n.project?.name ?? null,
          channel_name: n.channel?.name ?? null,
        }));
        setNotifications(shaped);
      }
    };

    fetchUserAndNotifications();
  }, [supabase]);

  useEffect(() => {
    if (!userId) return;

    const channel = supabase
      .channel(`notifications:${userId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "notifications",
          filter: `recipient_id=eq.${userId}`,
        },
        async (payload) => {
          const { data } = await supabase
            .from("notifications")
            .select(`
              id, type, read, created_at,
              project_id, channel_id, message_id,
              content, preview,
              sender:profiles!notifications_sender_id_fkey (
                id, full_name, avatar_url
              ),
              project:projects ( name ),
              channel:channels ( name )
            `)
            .eq("id", payload.new.id)
            .single();

          if (data) {
            const shaped = {
              ...data,
              sender: (data as any).sender ?? null,
              project_name: (data as any).project?.name ?? null,
              channel_name: (data as any).channel?.name ?? null,
            } as Notification;

            setNotifications((prev) => [shaped, ...prev]);
            playSound(shaped.type);

            if (!isInboxPage) {
              const toast: ToastProps = {
                id: shaped.id,
                type: shaped.type,
                title: shaped.sender?.full_name ?? "Nudge",
                message: shaped.preview,
                projectName: shaped.project_name ?? undefined,
                channelName: shaped.channel_name ?? undefined,
                onClose: (id) => setToasts((prev) => prev.filter((t) => t.id !== id)),
                onClick: () => {
                  window.location.href = "/space/inbox";
                },
              };

              setToasts((prev) => [toast, ...prev].slice(0, 5));
            }

            if (typeof window !== "undefined" && "Notification" in window && Notification.permission === "granted" && document.visibilityState !== "visible") {
              new Notification(shaped.sender?.full_name ?? "Nudge", {
                body: shaped.preview,
                icon: "/favicon.ico",
              });
            }
          }
        }
      )
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "notifications",
          filter: `recipient_id=eq.${userId}`,
        },
        (payload) => {
          setNotifications((prev) =>
            prev.map((n) => (n.id === payload.new.id ? { ...n, ...payload.new } : n))
          );
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [userId, supabase, playSound, isInboxPage]);

  useEffect(() => {
    if (typeof window !== "undefined" && "Notification" in window) {
      if (Notification.permission === "default") {
        Notification.requestPermission();
      }
    }
  }, []);

  const markAsRead = async (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
    await supabase.from("notifications").update({ read: true }).eq("id", id);
  };

  const markAllAsRead = async () => {
    if (!userId) return;
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    await supabase
      .from("notifications")
      .update({ read: true })
      .eq("recipient_id", userId)
      .eq("read", false);
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <NotificationContext.Provider value={{ notifications, unreadCount, markAsRead, markAllAsRead }}>
      {children}
      <ToastContainer toasts={toasts} onClose={(id) => setToasts((prev) => prev.filter((t) => t.id !== id))} />
    </NotificationContext.Provider>
  );
}